"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Person of Interest - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Person of Interest (POI) Resolution Engine
Author: Engineering Division, MicroCorp AI
License: Commercial / Enterprise
"""

import logging
import sys
import json
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Set
import redis

# Configure structured logging for machine/human readability
logging.basicConfig(
    level=logging.INFO,
    format='{"time": "%(asctime)s", "level": "%(levelname)s", "module": "%(name)s", "message": "%(message)s"}'
)
logger = logging.getLogger("POI-Resolver")

class POIError(Exception):
    """Base exception for all POI operations with explicit remediation steps."""
    def __init__(self, message: str, remediation: str, exit_code: int = 1):
        super().__init__(message)
        self.message = message
        self.remediation = remediation
        self.exit_code = exit_code

class RedisConnectionError(POIError):
    pass

@dataclass
class TelemetryEvent:
    event_id: str
    source_system: str
    identifiers: Dict[str, str]  # e.g., {"email": "user@example.com", "mac": "00:11:22:33:44:55"}
    timestamp: int
    confidence_score: float = 1.0

@dataclass
class CanonicalPOI:
    poi_id: str
    aliases: Set[str] = field(default_factory=set)
    first_seen: int = 0
    last_seen: int = 0
    risk_score: float = 0.0

class POIEngine:
    def __init__(self, redis_url: str = "redis://localhost:6379/0"):
        try:
            self.client = redis.Redis.from_url(redis_url, decode_responses=True)
            self.client.ping()
        except Exception as e:
            raise RedisConnectionError(
                message=f"Failed to connect to Redis instance at {redis_url}: {str(e)}",
                remediation="Ensure Redis is running and REDIS_URL environment variable is set correctly. Run 'redis-server' or check network rules.",
                exit_code=2
            )

    def resolve_entity(self, event: TelemetryEvent) -> str:
        """
        Resolves incoming telemetry identifiers to a canonical POI ID.
        If no match exists, mints a new canonical POI ID.
        """
        try:
            matched_poi_id: Optional[str] = None
            
            # 1. Check all identifiers against existing index
            for id_type, id_val in event.identifiers.items():
                index_key = f"idx:{id_type}:{id_val}"
                existing_poi = self.client.get(index_key)
                if existing_poi:
                    matched_poi_id = existing_poi
                    logger.info(f"Match found via {id_type}={id_val} -> POI:{matched_poi_id}")
                    break

            # 2. Mint new POI if unmapped
            if not matched_poi_id:
                matched_poi_id = f"poi_{event.event_id[:12]}"
                logger.info(f"No existing mapping found. Minting new POI:{matched_poi_id}")

            # 3. Index all identifiers to this canonical POI
            pipe = self.client.pipeline()
            for id_type, id_val in event.identifiers.items():
                index_key = f"idx:{id_type}:{id_val}"
                pipe.set(index_key, matched_poi_id)
            
            # Update POI metadata hash
            poi_meta_key = f"poi:meta:{matched_poi_id}"
            pipe.hset(poi_meta_key, mapping={
                "last_seen": event.timestamp,
                "source": event.source_system
            })
            pipe.hsetnx(poi_meta_key, "first_seen", event.timestamp)
            pipe.execute()

            return matched_poi_id

        except redis.RedisError as re:
            logger.error(f"Redis operational failure during resolution: {re}")
            raise POIError(
                message=f"Redis command failed: {str(re)}",
                remediation="Check Redis memory limits, eviction policies, and cluster health.",
                exit_code=3
            )

if __name__ == "__main__":
    try:
        # Example execution payload
        engine = POIEngine()
        sample_event = TelemetryEvent(
            event_id="e-998877665544",
            source_system="access-control-gateway-01",
            identifiers={
                "email": "operative.delta@microcorp.internal",
                "badge_id": "B-88392"
            },
            timestamp=1711900000
        )
        canonical_id = engine.resolve_entity(sample_event)
        print(json.dumps({"status": "success", "canonical_poi_id": canonical_id}, indent=2))
        
    except POIError as pe:
        sys.stderr.write(f"\n❌ Error: {pe.message}\n💡 Fix: {pe.remediation}\n\n")
        sys.exit(pe.exit_code)
    except Exception as unexpected:
        sys.stderr.write(f"\n❌ Critical Unhandled Error: {str(unexpected)}\n💡 Fix: Check logs and file bug report.\n\n")
        sys.exit(127)