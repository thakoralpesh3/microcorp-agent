"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: macOS Git Trust & eMudhra Certificate Mitigation Suite - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Diagnostic utility to verify Git HTTPS connectivity against eMudhra-protected remotes.
Author: Senior Product Architect, MicroCorp AI
"""

import sys
import ssl
import subprocess
import urllib.request
from urllib.error import URLError, HTTPError

def get_git_remote_url() -> str:
    try:
        result = subprocess.run(
            ["git", "config", "--get", "remote.origin.url"],
            capture_output=True, text=True, check=True
        ):
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        return "https://github.com/enterprise/default-repo.git"

def diagnose_ssl_trust(url: str):
    print(f"[DIAGNOSTIC] Analyzing TLS connection to: {url}")
    
    # Parse hostname from git URL (handles both SSH-like and HTTPS URLs)
    if url.startswith("git@"):
        host = url.split(":")[0].replace("git@", "")
    elif "://" in url:
        host = url.split("://")[1].split("/")[0]
    else:
        host = url.split("/")[0]

    context = ssl.create_default_context()
    
    try:
        print(f"[CONNECT] Attempting TLS handshake with {host}:443...")
        with urllib.request.urlopen(f"https://{host}", timeout=5, context=context) as response:
            print(f"[SUCCESS] TLS Handshake successful! Status Code: {response.status}")
    except ssl.SSLCertError as e:
        print(f"[CRITICAL] SSL Certificate Verification Failed: {e}", file=sys.stderr)
        print("[REMEDIATION] Run the mitigate-emudhra.sh script to update your Git CA bundle.", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"[WARNING] Network or HTTP error during connection test: {e}")

if __name__ == "__main__":
    remote_url = get_git_remote_url()
    diagnose_ssl_trust(remote_url)