"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: USPS Official ZIP Code Boundary Polygons - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
USPS Boundary Ingestion CLI Tool
MicroCorp AI Engineering Division

Usage:
  python ingest_zips.py --input ./data/usps_zips.geojson --db "postgresql://user:pass@localhost:5432/geo_db"
"""

import argparse
import sys
import os
import geopandas as gpd
from sqlalchemy import create_engine
from sqlalchemy.exc import OperationalError

def log_error(message: str, exit_code: int = 1):
    """Prints actionable error message to stderr and exits with standard code."""
    sys.stderr.write(f"\n❌ ERROR: {message}\n")
    sys.stderr.write("👉 NEXT STEP: Check connection strings, file paths, and ensure PostGIS is installed.\n\n")
    sys.exit(exit_code)

def main():
    parser = argparse.ArgumentParser(description="Ingest USPS ZIP Boundary Polygons into PostGIS.")
    parser.add_argument("--input", required=True, help="Path to raw GeoJSON or Shapefile.")
    parser.add_argument("--db", required=True, help="SQLAlchemy connection URI.")
    parser.add_argument("--table", default="usps_zip_boundaries", help="Target database table name.")
    args = parser.parse_args()

    # Validate input file existence
    if not os.path.exists(args.input):
        log_error(f"Input file not found at '{args.input}'. Verify path and try again.")

    print(f"🔄 Loading geospatial file: {args.input}...")
    try:
        # Load using GeoPandas
        gdf = gpd.read_file(args.input)
    except Exception as e:
        log_error(f"Failed to parse geospatial file. Underlying parser error: {str(e)}")

    # Standardize projection to WGS84 (EPSG:4326)
    if gdf.crs is None or gdf.crs.to_epsg() != 4326:
        print("⚠️ CRS missing or non-WGS84 detected. Reprojecting to EPSG:4326...")
        gdf = gdf.to_crs(epsg=4326)

    # Validate required columns
    required_cols = {"zip_code", "geometry"}
    if not required_cols.issubset(gdf.columns):
        log_error(f"Missing required columns. Expected at least {required_cols}, found {set(gdf.columns)}. "
                  "Normalize your source attributes prior to running ingestion.")

    print(f"🔌 Connecting to database engine...")
    try:
        engine = create_engine(args.db)
        # Test connection
        with engine.connect() as conn:
            pass
    except OperationalError as oe:
        log_error(f"Could not connect to database instance. Connection string check failed: {str(oe)}")

    print(f"🚀 Writing {len(gdf)} records to table '{args.table}' (this may take a moment)...")
    try:
        gdf.to_sql(
            name=args.table,
            con=engine,
            if_exists='append',
            index=False,
            dtype={'geometry': gpd.array.GeometryDtype()}
        )
        print(f"✨ Successfully ingested {len(gdf)} USPS ZIP boundary polygons into {args.table}.")
    except Exception as db_err:
        log_error(f"Database insertion failed during bulk load: {str(db_err)}")

if __name__ == "__main__":
    main()