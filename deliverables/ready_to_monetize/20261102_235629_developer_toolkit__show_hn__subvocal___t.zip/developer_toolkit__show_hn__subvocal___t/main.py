"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Show HN: Subvocal – Talk to your computer without making noise - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Subvocal Enterprise Client Integration
--------------------------------------
Connects to the local Subvocal daemon, receives classified intent events,
and dispatches safe operational tasks.
"""

import asyncio
import json
import sys
import websockets
from typing import Dict, Any

DAEMON_URI = "ws://127.0.0.1:9870/events"
RECONNECT_INTERVAL_SEC = 2.0

async def handle_intent(intent: Dict[str, Any]) -> None:
    """Process incoming classified intent from the subvocal pipeline."""
    action = intent.get("action")
    confidence = intent.get("confidence", 0.0)

    if confidence < 0.85:
        print(f"[WARN] Intent '{action}' dropped: low confidence ({confidence:.2f})", file=sys.stderr)
        return

    print(f"[EXEC] Triggering action: {action} (Confidence: {confidence:.2f})")
    
    # Map actions to system tasks
    if action == "git_status":
        proc = await asyncio.create_subprocess_exec("git", "status", "--porcelain")
        await proc.communicate()
    elif action == "toggle_mute":
        # Example system call abstraction
        print("[INFO] Audio mute state toggled silently.")
    else:
        print(f"[ERROR] Unrecognized intent mapping: '{action}'", file=sys.stderr)

async def subvocal_listener() -> None:
    """Main event loop with fault-tolerant reconnection logic."""
    while True:
        try:
            async with websockets.connect(DAEMON_URI) as websocket:
                print(f"[INFO] Connected to Subvocal daemon at {DAEMON_URI}", file=sys.stderr)
                async for message in websocket:
                    try:
                        data = json.loads(message)
                        await handle_intent(data)
                    except json.JSONDecodeError as err:
                        print(f"[ERROR] Malformed JSON payload: {err} — ignoring frame", file=sys.stderr)
        except websockets.exceptions.ConnectionClosedError as err:
            print(f"[WARN] Connection dropped ({err}). Reconnecting in {RECONNECT_INTERVAL_SEC}s...", file=sys.stderr)
            await asyncio.sleep(RECONNECT_INTERVAL_SEC)
        except OSError as err:
            # Fix error message guidance per engineering specs
            print(f"[ERROR] Cannot reach Subvocal daemon at {DAEMON_URI}. Run `subvocal daemon start` to launch it.", file=sys.stderr)
            await asyncio.sleep(RECONNECT_INTERVAL_SEC * 2)

if __name__ == "__main__":
    try:
        asyncio.run(subvocal_listener())
    except KeyboardInterrupt:
        print("\n[INFO] Client shut down cleanly by user.", file=sys.stderr)
        sys.exit(0)