"""
MicroCorp AI - Turnkey Deliverable
Asset: Python Web Automation & Agent Integration Specialist - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

"""
Module: browser_agent_core.py
Description: Production-grade async Playwright wrapper optimized for AI agent consumption.
"""

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("BrowserAgentCore")

class BrowserAgentSession:
    def __init__(self, headless: bool = True, proxy: Optional[str] = None):
        self.headless = headless
        self.proxy = proxy
        self._playwright = None
        self._browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None

    async def __aenter__(self):
        self._playwright = await async_playwright().start()
        launch_args = {
            "headless": self.headless,
            "args": [
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage"
            ]
        }
        if self.proxy:
            launch_args["proxy"] = {"server": self.proxy}

        self._browser = await self._playwright.chromium.launch(**launch_args)
        self.context = await self._browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            viewport={"width": 1280, "height": 800},
            device_scale_factor=1.0,
        )
        self.page = await self.context.new_page()
        logger.info("Browser session initialized successfully.")
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.context:
            await self.context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
        logger.info("Browser session terminated and cleaned up.")

    async def navigate_and_snapshot(self, url: str) -> Dict[str, Any]:
        """Navigates to URL and extracts a filtered accessibility tree for LLM consumption."""
        try:
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            
            # Handle unexpected popups or cookie banners heuristically
            await self._dismiss_common_overlays()

            # Extract accessibility snapshot (Token efficient)
            accessibility_tree = await self.page.accessibility.snapshot()
            
            # Compress and serialize meaningful elements
            sanitized_tree = self._sanitize_accessibility_tree(accessibility_tree)
            
            return {
                "status": "success",
                "url": self.page.url,
                "title": await self.page.title(),
                "dom_snapshot": sanitized_tree
            }
        except Exception as e:
            logger.error(f"Navigation failed for {url}: {str(e)}")
            return {
                "status": "error",
                "url": url,
                "message": str(e),
                "dom_snapshot": None
            }

    async def _dismiss_common_overlays(self):
        """Attempts to close typical cookie consent or newsletter modals."""
        common_selectors = [
            "button:has-text('Accept All')",
            "button:has-text('I Agree')",
            "button:has-text('Accept')",
            "[aria-label='Close']",
            ".cookie-banner-close"
        ]
        for selector in common_selectors:
            try:
                locator = self.page.locator(selector).first
                if await locator.is_visible(timeout=1000):
                    await locator.click()
                    logger.info(f"Dismissed overlay using selector: {selector}")
                    break
            except Exception:
                continue

    def _sanitize_accessibility_tree(self, node: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Strips redundant metadata from the accessibility tree to save LLM context window space."""
        if not node:
            return None
        
        role = node.get("role")
        name = node.get("name")
        value = node.get("value")
        children = node.get("children", [])

        # Filter out purely structural noise roles
        if role in ["generic", "none"] and not name and not children:
            return None

        cleaned_node: Dict[str, Any] = {"role": role}
        if name:
            cleaned_node["name"] = name
        if value:
            cleaned_node["value"] = value

        if children:
            filtered_children = [
                self._sanitize_accessibility_tree(child) 
                for child in children 
                if self._sanitize_accessibility_tree(child) is not None
            ]
            if filtered_children:
                cleaned_node["children"] = filtered_children

        return cleaned_node

# --- Execution Example ---
async def main():
    async with BrowserAgentSession(headless=True) as session:
        result = await session.navigate_and_snapshot("https://news.ycombinator.com")
        print(json.dumps(result, indent=2))

if __name__ == "__main__":
    asyncio.run(main())

# ============================================================
# Module Implementation Snippet
# ============================================================

"""
Module: agent_executor_loop.py
Description: Resilient tool executor with automated retry and DOM state feedback.
"""

from typing import Callable, Awaitable
from playwright.async_api import Page, TimeoutError as PlaywrightTimeoutError

async def execute_agent_action_with_recovery(
    page: Page, 
    action_name: str, 
    action_fn: Callable[[], Awaitable[Any]], 
    max_retries: int = 2
) -> Dict[str, Any]:
    """
    Executes a browser action with automated error capture and self-healing context injection.
    """
    attempt = 0
    while attempt <= max_retries:
        try:
            result = await action_fn()
            return {"success": True, "action": action_name, "result": result}
        except PlaywrightTimeoutError as pte:
            attempt += 1
            if attempt > max_retries:
                return {
                    "success": False,
                    "action": action_name,
                    "error": f"Timeout after {max_retries} retries: {str(pte)}",
                    "recovery_hint": "Element not found or interactive. Re-examine DOM snapshot."
                }
            await page.wait_for_timeout(1000 * attempt) # Exponential backoff
        except Exception as e:
            return {
                "success": False,
                "action": action_name,
                "error": str(e),
                "recovery_hint": "Unexpected exception during interaction."
            }
    return {"success": False, "action": action_name, "error": "Max retries exceeded."}

# ============================================================
# Module Implementation Snippet
# ============================================================

await page.route("**/*.{png,jpg,jpeg,svg,css,font,woff}", lambda route: route.abort())