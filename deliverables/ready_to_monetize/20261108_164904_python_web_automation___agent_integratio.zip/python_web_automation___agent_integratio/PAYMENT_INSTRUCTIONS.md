### Direct UPI Payment Instructions
- **Payee UPI ID:** `talpesh100@ybl`
- **Payee Name:** Alpesh Thakor
- **Amount Due:** ₹399.00 INR (~$4.99 USD)
- **Reference / Order ID:** `ORDER_9C95844E`
- **Transaction Note:** `MicroCorp: Python Web Automation & Agent `

**Supported Apps:** PhonePe, Google Pay, Paytm, BHIM, Amazon Pay, Cred, or any Indian banking app.
