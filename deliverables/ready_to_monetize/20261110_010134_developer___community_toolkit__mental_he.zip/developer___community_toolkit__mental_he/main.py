"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer & Community Toolkit: Mental Health & Wellness Frameworks for Tech Teams - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Cognitive WIP Limiter
Prevents developer burnout by enforcing strict limits on concurrent active tasks.
"""

import sys
import json
from typing import Dict, List

MAX_CONCURRENT_TASKS = 3

def evaluate_developer_load(developer_id: str, active_tasks: List[Dict]) -> None:
    """
    Evaluates active task load against cognitive safety limits.
    Fails the build/check if an engineer exceeds the threshold.
    """
    active_count = len([t for t in active_tasks if t.get("status") == "in_progress"])
    
    print(f"[WIP-GUARD] Evaluating workload for developer: {developer_id}")
    print(f"[WIP-GUARD] Active tasks in progress: {active_count}/{MAX_CONCURRENT_TASKS}")
    
    if active_count > MAX_CONCURRENT_TASKS:
        print(f"\n❌ CRITICAL: Cognitive Load Threshold Exceeded for {developer_id}!")
        print(f"   Cause: User has {active_count} tasks in progress (Max allowed: {MAX_CONCURRENT_TASKS}).")
        print(f"   Fix: Move {active_count - MAX_CONCURRENT_TASKS} task(s) back to 'Backlog' before picking up new work.")
        sys.exit(2)  # Exit code 2: Resource exhaustion (Cognitive)
    
    print(f"✅ PASS: Workload within sustainable operational limits.\n")
    sys.exit(0)

if __name__ == "__main__":
    # Simulated payload from GitHub/Jira webhook
    sample_payload = {
        "developer_id": "eng-alice-42",
        "active_tasks": [
            {"id": "MC-101", "status": "in_progress", "title": "Refactor auth middleware"},
            {"id": "MC-104", "status": "in_progress", "title": "Fix database connection leak"},
            {"id": "MC-109", "status": "in_progress", "title": "Update API swagger docs"},
            {"id": "MC-112", "status": "in_progress", "title": "Investigate flaky CI test"}
        ]
    }
    
    evaluate_developer_load(sample_payload["developer_id"], sample_payload["active_tasks"])