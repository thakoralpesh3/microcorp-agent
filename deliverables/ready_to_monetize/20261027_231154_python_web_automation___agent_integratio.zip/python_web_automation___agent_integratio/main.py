"""
MicroCorp AI - Turnkey Deliverable
Asset: Python Web Automation & Agent Integration Specialist - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

"""
Module: web_agent_extractor.py
Description: Production-grade asynchronous web automation and typed extraction engine.
Dependencies: playwright, pydantic>=2.0
Quick Fix for Missing Dependencies: Run `pip install playwright pydantic && playwright install chromium`
"""

import asyncio
import logging
from typing import List, Optional
from pydantic import BaseModel, Field, ValidationError
from playwright.async_api import async_playwright, Page, BrowserContext, expect

# Configure structured logging respecting pipe/TTY conventions
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("WebAgentSpecialist")

# --- 1. TYPED EXTRACTION SCHEMAS ---

class ProductListing(BaseModel):
    title: str = Field(..., description="The official product title.")
    price_usd: float = Field(..., description="Extracted price normalized to USD float.")
    in_stock: bool = Field(default=True, description="Stock availability status.")
    detail_url: Optional[str] = Field(None, description="Absolute URL to product details.")

class ExtractionResult(BaseModel):
    query: str
    items: List[ProductListing]
    total_found: int

# --- 2. STEALTH & BROWSER FACTORY ---

async def create_stealth_context(p) -> tuple:
    """Spawns an optimized, headless Chromium browser instance with anti-detection patches."""
    browser = await p.chromium.launch(
        headless=True,
        args=[
            "--disable-blink-features=AutomationControlled",
            "--disable-infobars",
            "--no-sandbox",
            "--disable-setuid-sandbox",
            "--disable-dev-shm-usage",
        ]
    )
    context = await browser.new_context(
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        viewport={"width": 1920, "height": 1080},
        locale="en-US",
        timezone_id="America/New_York"
    )
    
    # Inject evasion scripts to mask automation flags
    await context.add_init_script("""
        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
        window.navigator.chrome = { runtime: {} };
        Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
    """)
    
    return browser, context

# --- 3. CORE EXTRACTION ENGINE ---

async def extract_product_data(target_url: str, search_term: str) -> ExtractionResult:
    """
    Navigates to a target site, executes search, and extracts typed data.
    Raises RuntimeError with corrective instructions if automation fails.
    """
    async with async_playwright() as p:
        try:
            browser, context = await create_stealth_context(p)
            page = await context.new_page()
            
            logger.info(f"Navigating to target endpoint: {target_url}")
            try:
                await page.goto(target_url, timeout=30000, wait_until="domcontentloaded")
            except Exception as e:
                raise RuntimeError(
                    f"Failed to reach {target_url} within 30s. "
                    "Fix: Check network connectivity or verify URL correctness."
                ) from e

            # Example Interaction: Handling a search input
            search_input = page.get_by_role("searchbox", name=re.compile("search", re.IGNORECASE))
            if await search_input.count() == 0:
                # Fallback to common CSS selectors if ARIA role is missing
                search_input = page.locator("input[name*='q'], input[name*='search']").first
            
            if await search_input.count() == 0:
                raise RuntimeError(
                    "Search input element not found on page. "
                    "Fix: Inspect target DOM and update the locator strategy."
                )

            await search_input.fill(search_term)
            await search_input.press("Enter")
            
            # Wait for results container using resilient assertion
            results_container = page.locator(".product-grid, [data-testid='results-container']").first
            try:
                await expect(results_container).to_be_visible(timeout=10000)
            except AssertionError as e:
                raise RuntimeError(
                    "Results container failed to render. "
                    "Fix: The site may be blocking headless requests or utilizing dynamic shadow DOMs."
                ) from e

            # Extract raw DOM elements
            raw_items = []
            cards = page.locator(".product-card, article")
            count = await cards.count()
            
            for i in range(min(count, 10))): # Limit to top 10 for agent efficiency
                card = cards.nth(i)
                title_elem = card.locator("h2, h3, .title").first
                price_elem = card.locator(".price, [data-price]").first
                link_elem = card.locator("a").first
                
                title = await title_elem.inner_text() if await title_elem.count() > 0 else "Unknown"
                price_text = await price_elem.inner_text() if await price_elem.count() > 0 else "0.00"
                
                # Normalize price string (e.g., "$49.99" -> 49.99)
                clean_price = float(''.join(c for c in price_text if c.isdigit() or c == '.'))
                
                href = await link_elem.get_attribute("href") if await link_elem.count() > 0 else None
                
                raw_items.append({
                    "title": title.strip(),
                    "price_usd": clean_price,
                    "in_stock": True,
                    "detail_url": href
                })

            # Validate via Pydantic to guarantee agent schema safety
            validated_listings = [ProductListing(**item) for item in raw_items]
            
            return ExtractionResult(
                query=search_term,
                items=validated_listings,
                total_found=len(validated_listings)
            )

        except ValidationError as ve:
            logger.error(f"Data schema mismatch: {ve}")
            raise RuntimeError(
                "Extracted web data failed Pydantic schema validation. "
                "Fix: Inspect target site layout changes against ProductListing model fields."
            ) from ve
        finally:
            await browser.close()

# --- 4. CLI / EXECUTION ENTRYPOINT ---
if __name__ == "__main__":
    import sys
    target = "https://example-ecommerce.com"
    query = "wireless mechanical keyboard"
    
    try:
        result = asyncio.run(extract_product_data(target, query))
        print(result.model_dump_json(indent=2))
    except RuntimeError as err:
        print(f"\x1b[31m[ERROR] {err}\x1b[0m", file=sys.stderr)
        sys.exit(1)

# ============================================================
# Module Implementation Snippet
# ============================================================

await page.route("**/*.{png,jpg,jpeg,svg,css,font,woff}", lambda route: route.abort())