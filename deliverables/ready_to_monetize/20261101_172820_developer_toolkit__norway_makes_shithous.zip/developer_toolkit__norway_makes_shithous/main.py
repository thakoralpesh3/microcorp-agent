"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Norway Makes Shithouses Great Again - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

import time
import json
import sqlite3
import machine
from umqtt.simple import MQTTClient

# Hardware Pin Definitions (Nordic Frost-Hardened Spec)
HEATER_RELAY_PIN = 21
LEVEL_SENSOR_TRIG = 5
LEVEL_SENSOR_ECHO = 18
TEMP_SENSOR_PIN = 4

class NordicFacilityNode:
    def __init__(self, client_id, broker_host):
        self.client_id = client_id
        self.broker_host = broker_host
        self.db_conn = sqlite3.connect("facility_edge.db")
        self.init_local_db()
        self.setup_hardware()

    def setup_hardware(self):
        self.heater = machine.Pin(HEATER_RELAY_PIN, machine.Pin.OUT)
        self.heater.value(0) # Default OFF
        print(f"[Init] Facility Node {self.client_id} hardware initialized.")

    def init_local_db(self):
        cursor = self.db_conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS telemetry_buffer (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER,
                payload TEXT,
                synced INTEGER DEFAULT 0
            )
        """)
        self.db_conn.commit()

    def read_sensors(self):
        # Simulated robust sensor reading with frost protection logic
        internal_temp = 4.2 # Celsius (Approaching freezing)
        septic_level_pct = 78.5
        door_cycles_today = 142
        
        # Frost Prevention Trigger: Activate heating trace if temp < 5.0°C
        if internal_temp < 5.0:
            self.heater.value(1)
            heater_status = "ACTIVE"
        else:
            self.heater.value(0)
            heater_status = "STANDBY"

        return {
            "facility_id": self.client_id,
            "timestamp": int(time.time()),
            "temperature_c": internal_temp,
            "septic_level_pct": septic_level_pct,
            "door_cycles": door_cycles_today,
            "heater_status": heater_status
        }

    def store_locally(self, data):
        cursor = self.db_conn.cursor()
        cursor.execute(
            "INSERT INTO telemetry_buffer (timestamp, payload) VALUES (?, ?)",
            (data["timestamp"], json.dumps(data))
        )
        self.db_conn.commit()

    def sync_to_cloud(self, mqtt_client):
        cursor = self.db_conn.cursor()
        cursor.execute("SELECT id, payload FROM telemetry_buffer WHERE synced = 0 LIMIT 50")
        rows = cursor.fetchall()
        
        for row in rows:
            msg_id, payload = row
            try:
                mqtt_client.publish(f"norway/facilities/{self.client_id}/telemetry", payload, qos=1)
                cursor.execute("UPDATE telemetry_buffer SET synced = 1 WHERE id = ?", (msg_id,))
                self.db_conn.commit()
            except Exception as e:
                print(f"[Network] Cloud sync failed: {e}. Retaining local WAL buffer.")
                break

# Execution entrypoint simulation
if __name__ == "__main__":
    node = NordicFacilityNode("lofoten-outpost-09", "mqtt.norway-infrastructure.io")
    while True:
        telemetry = node.read_sensors()
        node.store_locally(telemetry)
        # Attempt sync in production loop...
        time.sleep(60)