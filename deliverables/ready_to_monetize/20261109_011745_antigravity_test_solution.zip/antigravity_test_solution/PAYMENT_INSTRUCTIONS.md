### Direct UPI Payment Instructions
- **Payee UPI ID:** `talpesh100@ybl`
- **Payee Name:** Alpesh Thakor
- **Amount Due:** ₹1799.00 INR (~$21.99 USD)
- **Reference / Order ID:** `ORDER_D6719D4B`
- **Transaction Note:** `MicroCorp: Antigravity Test Solution`

**Supported Apps:** PhonePe, Google Pay, Paytm, BHIM, Amazon Pay, Cred, or any Indian banking app.
