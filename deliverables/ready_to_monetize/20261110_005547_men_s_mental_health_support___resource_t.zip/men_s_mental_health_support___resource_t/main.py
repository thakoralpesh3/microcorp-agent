"""
MicroCorp AI - Turnkey Deliverable
Asset: Men's Mental Health Support & Resource Toolkit for Developers - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
dev-pulse: Developer Cognitive Telemetry & Circuit Breaker CLI
Usage: python3 dev-pulse.py [--check] [--log]
"""

import sys
import datetime
import json
from pathlib import Path

LOG_FILE = Path.home() / ".dev_pulse_telemetry.json"

def display_help():
    print("dev-pulse v1.0.0 — Developer Mental Health Telemetry")
    print("\nUsage:")
    print("  python3 dev-pulse.py check    Run cognitive load assessment")
    print("  python3 dev-pulse.py summary  View historical burnout risk")
    print("\nFlags:")
    print("  --help                        Show this help message")

def run_check():
    print("=== 🩺 Dev-Pulse Cognitive Telemetry Check ===")
    try:
        focus = int(input("1. Rate your current focus level (1-10): "))
        stress = int(input("2. Rate your current stress/frustration level (1-10): "))
        hours_seated = float(input("3. Hours continuously seated without a break: "))
        hydrated = input("4. Have you drank water in the last 2 hours? (y/n): ").strip().lower()
    except ValueError:
        print("❌ Error: Invalid input type. Please enter numbers where requested.")
        sys.exit(1)

    # Diagnostic logic (Circuit Breaker Evaluation)
    warnings = []
    if stress >= 8:
        warnings.warn("CRITICAL: Stress level high. Execute a 15-minute walk immediately.")
    if hours_seated > 3.0:
        warnings.append("WARNING: Sedentary threshold exceeded. Stand up, stretch, adjust posture.")
    if hydrated == 'n':
        warnings.append("WARNING: Dehydration impairs cognitive performance. Grab 500ml of water.")
    
    telemetry = {
        "timestamp": datetime.datetime.now().isoformat(),
        "focus": focus,
        "stress": stress,
        "hours_seated": hours_seated,
        "hydrated": hydrated == 'y'
    }
    
    # Append to local log
    history = []
    if LOG_FILE.exists():
        try:
            history = json.loads(LOG_FILE.read_text())
        except json.JSONDecodeError:
            history = []
    
    history.append(telemetry)
    LOG_FILE.write_text(json.dumps(history, indent=2))

    print("\n--- Diagnostic Results ---")
    if not warnings:
        print("✨ All systems nominal. Keep shipping responsibly.")
    else:
        for w in warnings:
            print(f"⚠️  {w}")
    print(f"Telemetry saved to {LOG_FILE}")

if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] == "--help":
        display_help()
        sys.exit(0)
    
    command = sys.argv[1]
    if command == "check":
        run_check()
    elif command == "summary":
        if not LOG_FILE.exists():
            print("Error: No telemetry found. Run `python3 dev-pulse.py check` first.")
            sys.exit(1)
        data = json.loads(LOG_FILE.read_text())
        print(f"Total logged check-ins: {len(data)}")
        avg_stress = sum(d['stress'] for d in data) / len(data)
        print(f"Average Stress Level: {avg_stress:.2f}/10")
    else:
        print(f"Error: Unknown command '{command}'. Run with --help for usage.")
        sys.exit(1)