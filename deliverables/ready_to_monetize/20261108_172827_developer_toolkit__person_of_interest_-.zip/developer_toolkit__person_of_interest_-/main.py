"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Person of Interest - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

"""
Subsystem: poi.core.resolver
Description: High-performance identity stitching engine using Disjoint Set Union.
"""
from typing import Dict, List, Set, Tuple
import sys

class EntityStitcher:
    def __init__(self) -> None:
        self.parent: Dict[str, str] = {}
        self.rank: Dict[str, int] = {}

    def _error_exit(self, message: str, fix: str, code: int) -> None:
        """Adheres to standard developer tooling error protocols."""
        print(f"❌ Error: {message}", file=sys.stderr)
        print(f"💡 Recommended Fix: {fix}", file=sys.stderr)
        sys.exit(code)

    def find(self, i: str) -> str:
        """Finds the root entity with path compression."""
        if i not in self.parent:
            self._error_exit(
                f"Entity ID '{i}' not found in resolution registry.",
                f"Run `poi entity register --id {i}` before attempting resolution.",
                code=10
            )
        
        path: List[str] = []
        root = i
        while root != self.parent[root]:
            path.append(root)
            root = self.parent[root]
        
        # Compress paths along the way
        for node in path:
            self.parent[node] = root
        return root

    def union(self, i: str, j: str) -> Tuple[str, bool]:
        """
        Merges two entity clusters based on observed shared identifiers.
        Returns the new root and a boolean indicating if a merge occurred.
        """
        try:
            root_i = self.find(i)
            root_j = self.find(j)
        except SystemExit:
            raise

        if root_i == root_j:
            return root_i, False

        # Union by rank optimization
        if self.rank[root_i] < self.rank[root_j]:
            self.parent[root_i] = root_j
            return root_j, True
        elif self.rank[root_i] > self.rank[root_j]:
            self.parent[root_j] = root_i
            return root_i, True
        else:
            self.parent[root_j] = root_i
            self.rank[root_i] += 1
            return root_i, True

    def register_entity(self, entity_id: str) -> None:
        if entity_id in self.parent:
            return
        self.parent[entity_id] = entity_id
        self.rank[entity_id] = 0

# --- Example Usage ---
if __name__ == "__main__":
    stitcher = EntityStitcher()
    stitcher.register_entity("ent_alpha_01")
    stitcher.register_entity("ent_beta_02")
    
    # Simulate discovering they are the same person via shared device fingerprint
    new_root, merged = stitcher.union("ent_alpha_01", "ent_beta_02")
    print(f"Resolution Result -> Root: {new_root}, Merged: {merged}")

# ============================================================
# Module Implementation Snippet
# ============================================================

"""
Subsystem: poi.graph.traversal
Description: Bounded N-degree graph explorer with cycle detection and memory limits.
"""
from collections import deque
from typing import Dict, List, Set, Generator
import sys

# Type alias for adjacency list representation
GraphRegistry = Dict[str, List[str]]

class BoundedGraphTraversal:
    def __init__(self, graph: GraphRegistry, max_depth: int = 3, max_nodes: int = 10000) -> None:
        self.graph = graph
        self.max_depth = max_depth
        self.max_nodes = max_nodes

    def trace_connections(self, start_id: str) -> Generator[Tuple[str, int], None, None]:
        """
        Performs a memory-safe BFS traversal yielding connected nodes and their distance.
        """
        if start_id not in self.graph:
            print(f"❌ Error: Start node '{start_id}' missing from graph index.", file=sys.stderr)
            print(f"💡 Recommended Fix: Verify index sync status using `poi index status`.", file=sys.stderr)
            sys.exit(20)

        visited: Set[str] = {start_id}
        queue: deque[Tuple[str, int]] = deque([(start_id, 0)])
        nodes_processed = 0

        while queue:
            current_node, depth = queue.popleft()
            nodes_processed += 1

            if nodes_processed > self.max_nodes:
                print(f"❌ Error: Traversal exceeded safety limit of {self.max_nodes} nodes.", file=sys.stderr)
                print(f"💡 Recommended Fix: Reduce `--depth` or filter signals using `--criteria`.", file=sys.stderr)
                sys.exit(21)

            yield current_node, depth

            if depth >= self.max_depth:
                continue

            for neighbor in self.graph.get(current_node, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, depth + 1))

# --- Example Usage ---
if __name__ == "__main__":
    mock_surveillance_network: GraphRegistry = {
        "device_A": ["ip_192_1", "account_X"],
        "ip_192_1": ["device_A", "device_B"],
        "account_X": ["device_A", "payment_card_9"],
        "device_B": ["ip_192_1", "account_Y"],
        "account_Y": ["device_B", "payment_card_9"],
        "payment_card_9": ["account_X", "account_Y"]
    }

    explorer = BoundedGraphTraversal(mock_surveillance_network, max_depth=2)
    print("Tracing connections from 'device_A':")
    for node, dist in explorer.trace_connections("device_A"):
        print(f"  [Depth {dist}] -> Connected Entity: {node}")