"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Person of Interest - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Person of Interest (POI) - Core Engine Reference Implementation
Author: Engineering Division, MicroCorp AI
License: Enterprise Commercial Grade
"""

import sys
import time
import json
import logging
import hashlib
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum

# Configure Structured Logging (Human or Machine readable based on TTY)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stdout
)
logger = logging.getLogger("poi.engine")

class ThreatLevel(Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

@dataclass
class TelemetryEvent:
    source_id: str
    entity_alias: str
    ip_address: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        """Validates telemetry payload structure. Raises ValueError on failure."""
        if not self.source_id or not self.entity_alias:
            raise ValueError(
                f"Invalid payload: source_id and entity_alias cannot be empty. "
                f"Received source_id='{self.source_id}', alias='{self.entity_alias}'. "
                f"Action: Verify upstream producer configuration."
            )

@dataclass
class CanonicalEntity:
    canonical_id: str
    aliases: set = field(default_factory=set)
    threat_score: float = 0.0
    last_seen: float = field(default_factory=time.time)

class EntityResolutionEngine:
    """
    Resolves disparate aliases into canonical entities and evaluates risk metrics.
    """
    def __init__(self, risk_threshold: float = 75.0):
        self.risk_threshold = risk_threshold
        self._registry: Dict[str, CanonicalEntity] = {}
        self._alias_index: Dict[str, str] = {}

    def _generate_canonical_id(self, primary_alias: str) -> str:
        return hashlib.sha256(primary_alias.lower().strip().encode('utf-8')).hexdigest()[:16]

    def ingest_event(self, event: TelemetryEvent) -> CanonicalEntity:
        """
        Ingests a telemetry event, resolving aliases and updating state.
        """
        try:
            event.validate()
        except ValueError as e:
            logger.error(f"Ingestion failed: {e}")
            raise

        alias = event.entity_alias.lower().strip()
        
        # Check if alias is already mapped
        if alias in self._alias_index:
            canonical_id = self._alias_index[alias]
            entity = self._registry[canonical_id]
        else:
            # Create new canonical entity
            canonical_id = self._generate_canonical_id(alias)
            if canonical_id not in self._registry:
                self._registry[canonical_id] = CanonicalEntity(canonical_id=canonical_id)
            entity = self._registry[canonical_id]
            entity.aliases.add(alias)
            self._alias_index[alias] = canonical_id

        # Update entity state
        entity.last_seen = event.timestamp
        self._evaluate_threat(entity, event)
        
        logger.debug(f"Resolved alias '{alias}' to Canonical ID: {canonical_id}")
        return entity

    def _evaluate_threat(self, entity: CanonicalEntity, event: TelemetryEvent) -> None:
        """Calculates risk heuristic based on incoming telemetry metadata."""
        risk_increment = event.metadata.get("risk_weight", 5.0)
        entity.threat_score = min(100.0, entity.threat_score + risk_increment)
        
        if entity.threat_score >= self.risk_threshold:
            logger.warning(
                f"SECURITY ALERT: Entity {entity.canonical_id} breached threat threshold! "
                f"Score: {entity.threat_score:.2f} (Aliases: {list(entity.aliases)})"
            )

# Example Execution Hook
if __name__ == "__main__":
    print("Initializing POI Entity Resolution Engine...")
    engine = EntityResolutionEngine(risk_threshold=20.0)

    sample_events = [
        TelemetryEvent(source_id="sensor-01", entity_alias="Agent_Alpha", ip_address="192.168.1.50", metadata={"risk_weight": 10.0}),
        TelemetryEvent(source_id="sensor-02", entity_alias="Agent_Alpha", ip_address="10.0.0.15", metadata={"risk_weight": 15.0}),
    ]

    for ev in sample_events:
        resolved = engine.ingest_event(ev)
        print(f"-> Entity {resolved.canonical_id} | Score: {resolved.threat_score} | Aliases: {resolved.aliases}")