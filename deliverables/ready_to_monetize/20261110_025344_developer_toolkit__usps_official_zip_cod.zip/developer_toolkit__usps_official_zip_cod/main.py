"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: USPS Official ZIP Code Boundary Polygons Integration Guide - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

"""
MicroCorp AI - USPS Polygon Ingestion Utility
Dependencies: geopandas, shapely, psycopg2-binary
"""
import os
import geopandas as gpd
from sqlalchemy import create_engine

def ingest_shapefile(shapefile_path: str, connection_string: str):
    """
    Ingests official USPS boundary shapefiles into a PostGIS database,
    ensuring proper CRS re-projection and geometry validity.
    """
    print(f"[*] Reading shapefile from: {shapefile_path}")
    gdf = gpd.read_file(shapefile_path)

    # 1. Enforce standard WGS 84 Coordinate Reference System (EPSG:4326)
    if gdf.crs != "EPSG:4326":
        print("[*] Re-projecting dataset to EPSG:4326...")
        gdf = gdf.to_crs("EPSG:4326")

    # 2. Fix invalid geometries (e.g., self-intersections, bow-ties)
    print("[*] Sanitizing geometries...")
    gdf['geometry'] = gdf['geometry'].buffer(0)

    # 3. Standardize column names for database schema mapping
    gdf = gdf.rename(columns={
        'ZCTA5CE10': 'zip_code',
        'STATEFP10': 'state_fp',
        'NAME10': 'city_name'
    })

    # Keep only required columns
    columns_to_keep = ['zip_code', 'state_fp', 'city_name', 'geometry']
    gdf = gdf[columns_to_keep]

    # 4. Stream to PostgreSQL via SQLAlchemy
    print("[*] Establishing database connection...")
    engine = create_engine(connection_string)

    print("[*] Writing polygons to PostGIS...")
    gdf.to_postgis(
        name='usps_zip_boundaries',
        con=engine,
        if_exists='append',
        index=False,
        chunksize=1000
    )
    print("[+] Ingestion complete successfully.")

if __name__ == "__main__":
    DB_URI = os.getenv("DATABASE_URL", "postgresql://user:pass@localhost:5432/geomdb")
    # ingest_shapefile("./data/cb_2023_us_zcta510_500k.shp", DB_URI)