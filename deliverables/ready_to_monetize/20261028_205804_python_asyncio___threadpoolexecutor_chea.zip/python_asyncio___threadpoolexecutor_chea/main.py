"""
MicroCorp AI - Turnkey Deliverable
Asset: Python Asyncio & ThreadPoolExecutor Cheatsheet - Developer Reference Card
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

import asyncio
from concurrent.futures import ThreadPoolExecutor
import time
from typing import List, Dict, Any

# Dedicated thread pool for blocking I/O (e.g., legacy DB queries, file writes)
IO_POOL = ThreadPoolExecutor(max_workers=16, thread_name_prefix="io_worker")

def blocking_database_query(user_id: int) -> Dict[str, Any]:
    """Simulates a blocking synchronous DB driver or ORM call."""
    time.sleep(0.05)  # Simulate network/disk latency
    return {"user_id": user_id, "status": "active", "tier": "enterprise"}

async def fetch_user_data_async(user_ids: List[int]) -> List[Dict[str, Any]]:
    """Fetches multiple user records concurrently without blocking the event loop."""
    loop = asyncio.get_running_loop()
    
    # Map each blocking call into the ThreadPoolExecutor
    futures = [
        loop.run_in_executor(IO_POOL, blocking_database_query, uid)
        for uid in user_ids
    ]
    
    # Await all futures concurrently
    results = await asyncio.gather(*futures)
    return results

# Example Execution Runner
if __name__ == "__main__":
    start = time.perf_counter()
    ids = list(range(100))
    user_records = asyncio.run(fetch_user_data_async(ids))
    print(f"Fetched {len(user_records)} records in {time.perf_counter() - start:.4f} seconds.")

# ============================================================
# Module Implementation Snippet
# ============================================================

import asyncio
import aiohttp
import time

async def fetch_with_semaphore(
    sem: asyncio.Semaphore, 
    session: aiohttp.ClientSession, 
    url: str
) -> dict:
    """Fetches a URL respecting a strict concurrency limit."""
    async with sem:
        try:
            async with session.get(url, timeout=5.0) as response:
                return {"url": url, "status": response.status}
        except asyncio.TimeoutError:
            return {"url": url, "status": "timeout"}
        except Exception as e:
            return {"url": url, "status": "error", "details": str(e)}

async def batch_client(urls: list[str], max_concurrent: int = 10) -> list[dict]:
    sem = asyncio.Semaphore(max_concurrent)
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_with_semaphore(sem, session, url) for url in urls]
        return await asyncio.gather(*tasks)

if __name__ == "__main__":
    test_urls = [f"https://httpbin.org/delay/1?id={i}" for i in range(30)]
    start = time.perf_counter()
    results = asyncio.run(batch_client(test_urls, max_concurrent=5))
    print(f"Completed {len(results)} requests in {time.perf_counter() - start:.2f}s")

# ============================================================
# Module Implementation Snippet
# ============================================================

# ❌ BAD: Blocks the entire event loop!
async def bad_handler():
    import time
    time.sleep(2)  # Event loop is completely frozen here!
    return "done"

# ✅ GOOD: Offloaded to the thread pool
async def good_handler():
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, time.sleep, 2)
    return "done"

# ============================================================
# Module Implementation Snippet
# ============================================================

# ✅ SAFE GATHER PATTERN
results = await asyncio.gather(*tasks, return_exceptions=True)
for res in results:
    if isinstance(res, Exception):
        logger.error(f"Task failed: {res}")
    else:
        process(res)

# ============================================================
# Module Implementation Snippet
# ============================================================

import uvloop
     uvloop.install()

# ============================================================
# Module Implementation Snippet
# ============================================================

for coro in asyncio.as_completed(tasks):
         result = await coro
         handle(result)