"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Norway Makes Shithouses Great Again - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

import time
import logging
from functools import wraps
from typing import Callable, Any

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("FrostGuardCircuitBreaker")

class CircuitOpenError(Exception):
    """Raised when the circuit breaker is tripped open to protect downstream systems."""
    pass

def frost_guard_breaker(failure_threshold: int = 3, recovery_time: float = 5.0) -> Callable:
    """
    Decorator implementing a robust circuit breaker pattern.
    Guards microservices against freezing under heavy load or network partitions.
    """
    def decorator(func: Callable) -> Callable:
        failures = 0
        last_failure_time = 0.0
        state = "CLOSED" # Options: CLOSED, OPEN, HALF-OPEN

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            nonlocal failures, last_failure_time, state

            now = time.time()

            # Check if recovery window has elapsed
            if state == "OPEN":
                if now - last_failure_time > recovery_time:
                    logger.info("[FROST-GUARD] Recovery window reached. Transitioning to HALF-OPEN.")
                    state = "HALF-OPEN"
                else:
                    logger.warning("[FROST-GUARD] Circuit OPEN. Rejecting execution.")
                    raise CircuitOpenError("Service protected by Frost-Guard. Downstream is frozen.")

            try:
                result = func(*args, **kwargs)
                
                # Success path
                if state in ["HALF-OPEN", "OPEN"]:
                    logger.info("[FROST-GUARD] Execution successful. Circuit CLOSED.")
                failures = 0
                state = "CLOSED"
                return result

            except Exception as e:
                failures += 1
                last_failure_time = time.time()
                logger.error(f"[FROST-GUARD] Failure recorded ({failures}/{failure_threshold}): {e}")

                if failures >= failure_threshold or state == "HALF-OPEN":
                    state = "OPEN"
                    logger.critical("[FROST-GUARD] Threshold reached. Circuit tripped to OPEN.")
                
                raise e

        return wrapper
    return decorator

# --- Example Usage ---
@frost_guard_breaker(failure_threshold=2, recovery_time=3.0)
def unstable_external_api_call(status: str) -> str:
    if status == "fail":
        raise ConnectionError("Upstream node dropped connection.")
    return "Data synchronized successfully."

if __name__ == "__main__":
    # Simulate failures tripping the breaker
    for i in range(3):
        try:
            unstable_external_api_call("fail")
        except Exception as err:
            print(f"Caught: {err}")
        time.sleep(0.5)

    print("\nWaiting for circuit recovery...")
    time.sleep(3.5)

    # Test recovery
    try:
        response = unstable_external_api_call("success")
        print(f"Response: {response}")
    except Exception as err:
        print(f"Caught: {err}")