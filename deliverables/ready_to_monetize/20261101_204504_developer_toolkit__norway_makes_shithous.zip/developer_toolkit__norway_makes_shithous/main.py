"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Norway makes shithouses great again - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
import os
import time
import subprocess
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

CPU_TEMP_PATH = "/sys/class/thermal/thermal_zone0/temp"
CRITICAL_TEMP_C = 80.0
LOW_VOLTAGE_THRESHOLD = 11.5 # Volts (12V DC system)

def read_cpu_temp() -> float:
    try:
        with open(CPU_TEMP_PATH, "r") as f:
            return float(f.read().strip()) / 1000.0
    except Exception:
        return 0.0

def trigger_thermal_throttle():
    logging.warning("CRITICAL: Low temperature or overheating detected. Enforcing power save profile.")
    subprocess.run(["sudo", "cpupower", "frequency-set", "-g", "powersave"], check=False)

def main_loop():
    logging.info("Starting MicroCorp Norway Thermal & Power Watchdog...")
    while True:
        temp = read_cpu_temp()
        if temp > CRITICAL_TEMP_C:
            trigger_thermal_throttle()
        
        # In production, read actual ADC voltage over I2C here
        time.sleep(10)

if __name__ == "__main__":
    main_loop()