"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: USPS Official ZIP Code Boundary Polygons - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

"""
Module: spatial_lookup.py
Description: High-performance ZIP code spatial lookup using PostGIS and SQLAlchemy.
"""

import os
from typing import Optional
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError

# Database connection string from environment
DB_URL = os.getenv("DATABASE_URL", "postgresql://user:pass@localhost:5432/geodb")

def get_engine() -> Engine:
    """Creates a thread-safe connection pool."""
    return create_engine(DB_URL, pool_size=5, max_overflow=10)

def get_zip_by_coordinates(engine: Engine, latitude: float, longitude: float) -> Optional[str]:
    """
    Performs an index-accelerated Point-in-Polygon lookup.
    
    Args:
        engine: SQLAlchemy database engine.
        latitude: WGS 84 latitude (-90 to 90).
        longitude: WGS 84 longitude (-180 to 180).
        
    Returns:
        String representation of the 5-digit ZIP code or None if not found.
    """
    query = text("""
        SELECT zip_code 
        FROM usps_zip_boundaries 
        WHERE ST_Contains(
            geom, 
            ST_SetSRID(ST_MakePoint(:lon, :lat), 4326)
        )
        LIMIT 1;
    """)
    
    try:
        with engine.connect() as conn:
            result = conn.execute(query, {"lon": longitude, "lat": latitude}).fetchone()
            return result[0] if result else None
    except SQLAlchemyError as e:
        # Structured error handling with clear operator messaging
        raise RuntimeError(
            f"Spatial query failed: {str(e)}. "
            f"Ensure PostGIS extension is enabled and table 'usps_zip_boundaries' has a GIST index on 'geom'."
        ) from e

if __name__ == "__main__":
    eng = get_engine()
    # Test point: Empire State Building
    lat, lon = 40.748817, -73.985428
    zip_code = get_zip_by_coordinates(eng, lat, lon)
    print(f"Coordinates ({lat}, {lon}) resolve to ZIP: {zip_code}")