"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Norway makes shithouses great again - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Norwegian Edge Watchdog & Thermal Regulation Daemon
Ensures system survival in unheated, extreme-environment enclosures.
"""

import os
import sys
import time
import logging
import subprocess
from pathlib import Path

# Configure Enterprise Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] (ThermalDaemon): %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)

TEMP_SENSOR_PATH = Path("/sys/class/thermal/thermal_zone0/temp")
MIN_SAFE_TEMP_C = 5.0  # Minimum operational hardware temp
CRITICAL_SHUTDOWN_TEMP_C = -5.0
CHECK_INTERVAL_SEC = 30

def read_system_temperature() -> float:
    """Reads hardware thermal zone or returns simulated reading for development."""
    try:
        if TEMP_SENSOR_PATH.exists():
            raw_temp = TEMP_SENSOR_PATH.read_text().strip()
            return float(raw_temp) / 1000.0
        # Fallback for development environments
        return 15.0
    except Exception as e:
        logging.error(f"Failed to read temperature sensor: {e}")
        return 10.0  # Safe default assumption

def adjust_system_workload(action: str):
    """Adjusts system concurrency via systemctl service scaling."""
    service_name = "norway-telemetry-worker.service"
    try:
        if action == "throttle":
            logging.warning("⚠️ Thermal threshold breached! Reducing worker concurrency...")
            subprocess.run(["systemctl", "stop", service_name], check=False)
        elif action == "resume":
            logging.info("✅ Temperature nominal. Restoring full operational capacity...")
            subprocess.run(["systemctl", "start", service_name], check=False)
    except Exception as e:
        logging.error(f"Failed to adjust system services: {e}")

def main_loop():
    logging.info("Initializing Nordic Thermal Watchdog...")
    while True:
        current_temp = read_system_temperature()
        logging.info(f"Current Core Temperature: {current_temp}°C")

        if current_temp < CRITICAL_SHUTDOWN_TEMP_C:
            logging.critical(f"🔥 CRITICAL FREEZE RISK ({current_temp}°C)! Initiating safe hibernation.")
            adjust_system_workload("throttle")
            # Execute emergency hardware flush if required
            sys.exit(1)
        elif current_temp < MIN_SAFE_TEMP_C:
            adjust_system_workload("throttle")
        else:
            adjust_system_workload("resume")

        time.sleep(CHECK_INTERVAL_SEC)

if __name__ == "__main__":
    if os.geteuid() != 0:
        logging.error("This daemon requires root privileges to manage system services.")
        sys.exit(1)
    main_loop()