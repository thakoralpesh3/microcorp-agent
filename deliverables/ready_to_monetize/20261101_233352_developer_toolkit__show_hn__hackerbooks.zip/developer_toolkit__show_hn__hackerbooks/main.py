"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Show HN: HackerBooks – HackerTube, but for books mentioned on HN - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

# filename: worker.py
import asyncio
import re
import sys
from typing import List, Optional
import httpx
from pydantic import BaseModel, Field

# Strict configuration & constants
HN_FIREBASE_BASE = "hacker-news.firebaseio.com/v0"
BOOK_PATTERN = re.compile(
    r"(?:read|reading|readings|book|books|author)\s+[:\"']?([A-Z0-9a-z\s,.-]{3,50})['\"]?",
    re.IGNORECASE,
)


class HNItem(BaseModel):
    id: int
    type: str
    title: Optional[str] = None
    text: Optional[str] = None
    by: Optional[str] = None
    kids: List[int] = Field(default_factory=list)


class ExtractedBook(BaseModel):
    title: string
    source_story_id: int
    mentioned_by: str


async def fetch_item(client: httpx.AsyncClient, item_id: int) -> Optional[HNItem]:
    """Fetches a single HN item with graceful error handling and backoff."""
    url = f"https://{HN_FIREBASE_BASE}/item/{item_id}.json"
    try:
        response = await client.get(url, timeout=5.0)
        if response.status_code == 429:
            print(
                f"[WARN] Rate limited by HN API. Backing off...", file=sys.stderr
            )
            await asyncio.sleep(2.0)
            return await fetch_item(client, item_id)
        response.raise_for_status()
        data = response.json()
        return HNItem(**data) if data else None
    except httpx.RequestError as e:
        print(
            f"[ERROR] Failed to fetch item {item_id}: {e}. Run `hb-cli doctor` to check connectivity.",
            file=sys.stderr,
        )
        return None


async def scan_top_stories(limit: int = 10):
    """Scans top HN stories and extracts potential book mentions."""
    async with httpx.AsyncClient() as client:
        top_stories_url = f"https://{HN_FIREBASE_BASE}/topstories.json"
        res = await client.get(top_stories_url)
        if res.status_code != 200:
            print(
                f"Error: Unable to reach HN Firebase (HTTP {res.status_code}). Check your network connection.",
                file=sys.stderr,
            )
            sys.exit(1)

        story_ids = res.json()[:limit]
        print(f"[*] Scanning {len(story_ids)} top Hacker News stories...")

        for sid in story_ids:
            story = await fetch_item(client, sid)
            if not story or not story.title:
                continue

            # Check title for book indicators
            match = BOOK_PATTERN.search(story.title)
            if match:
                print(
                    f"[FOUND] Potential Book -> '{match.group(1)}' in Story: {story.title} (ID: {story.id})"
                )


if __name__ == "__main__":
    try:
        asyncio.run(scan_top_stories(5))
    except KeyboardInterrupt:
        print("\n[INFO] Worker interrupted by user. Exiting cleanly.")
        sys.exit(0)

# ============================================================
# Module Implementation Snippet
# ============================================================

# filename: enricher.py
import functools
import httpx
from typing import Dict, Any


class BookEnricher:
    """Enriches extracted book titles with Open Library API metadata."""

    BASE_URL = "https://openlibrary.org/search.json"

    def __init__(self):
        self.client = httpx.Client(timeout=4.0)

    @functools.lru_cache(maxsize=1024)
    def fetch_metadata(self, title: str) -> Dict[Any, Any]:
        params = {"title": title, "limit": 1}
        try:
            response = self.client.get(self.BASE_URL, params=params)
            response.raise_for_status()
            data = response.json()

            if data.get("numFound", 0) > 0:
                doc = data["docs"][0]
                return {
                    "title": doc.get("title"),
                    "author": doc.get("author_name", ["Unknown"])[0],
                    "first_publish_year": doc.get("first_publish_year"),
                    "isbn": doc.get("isbn", [None])[0],
                    "cover_id": doc.get("cover_i"),
                }
            return {"error": "Not found in Open Library"}
        except httpx.HTTPStatusError as e:
            return {
                "error": f"API Error {e.response.status_code} — check Open Library status."
            }
        except httpx.RequestError:
            return {
                "error": "Network timeout reaching Open Library. Try again later."
            }


if __name__ == "__main__":
    enricher = BookEnricher()
    result = enricher.fetch_metadata("Designing Data-Intensive Applications")
    print(result)