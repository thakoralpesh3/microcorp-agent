### Direct UPI Payment Instructions
- **Payee UPI ID:** `talpesh100@ybl`
- **Payee Name:** Alpesh Thakor
- **Amount Due:** ₹3999.00 INR (~$49.00 USD)
- **Reference / Order ID:** `ORDER_0C9D7DD1`
- **Transaction Note:** `MicroCorp: FullStack ECommerce Kit`

**Supported Apps:** PhonePe, Google Pay, Paytm, BHIM, Amazon Pay, Cred, or any Indian banking app.
