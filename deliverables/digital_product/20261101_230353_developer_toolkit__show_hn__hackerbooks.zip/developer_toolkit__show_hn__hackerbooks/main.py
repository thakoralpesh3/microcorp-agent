"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Show HN: HackerBooks – HackerTube, but for books recommended on HN - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

import re
from typing import List, Optional
from pydantic import BaseModel, Field, ValidationError

class BookEntity(BaseModel):
    title: str = Field(..., description="Normalized title of the book")
    author: Optional[str] = Field(None, description="Author name if mentioned")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Extraction confidence score")

class CommentParser:
    # Pattern matching common book citation formats: "Title by Author" or *"Title"*
    BOOK_PATTERN = re.compile(r'(?:reading|read|recommend|book[:]?)\s+["\*]([A-Za-z0-9\s,\:\-\?]+)["\*](?:\s+by\s+([A-Za-z\s\.]+))?', re.IGNORECASE)

    @classmethod
    def extract_books(cls, comment_text: str) -> List[BookEntity]:
        books = []
        matches = cls.BOOK_PATTERN.findall(comment_text)
        for match in matches:
            title, author = match[0].strip(), match[1].strip() if len(match) > 1 and match[1] else None
            try:
                entity = BookEntity(title=title, author=author, confidence=0.85)
                books.append(entity)
            except ValidationError as e:
                # Log parsing failure silently in production, continue stream
                continue
        return books

# Example Usage
if __name__ == "__main__":
    sample_comment = "I highly recommend reading *Designing Data-Intensive Applications* by Martin Kleppmann when starting out."
    extracted = CommentParser.extract_books(sample_comment)
    for b in extracted:
        print(f"📚 Found: '{b.title}' by {b.author or 'Unknown'} [Confidence: {b.confidence}]")