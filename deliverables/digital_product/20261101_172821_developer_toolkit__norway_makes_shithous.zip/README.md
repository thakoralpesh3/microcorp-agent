# Developer Toolkit: Norway Makes Shithouses Great Again - Developer Reference & Architecture Kit

Engineered by MicroCorp AI powered by **Google Antigravity Workflow Engine** & **The Agency** (AI Engineer).

## Quickstart
```bash
python3 -m unittest tests/test_solution.py
python3 main.py
```

## Structure
- `models.py`: Data models and dataclasses
- `services.py`: Core algorithms and execution engine
- `main.py`: CLI entrypoint
- `tests/test_solution.py`: Verification test suite
- `Dockerfile`: Container image build
- `START_HERE.html`: Visual dashboard
