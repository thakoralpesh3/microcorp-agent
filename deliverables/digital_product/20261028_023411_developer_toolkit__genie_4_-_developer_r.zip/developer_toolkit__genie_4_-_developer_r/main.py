"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Genie 4 - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

import asyncio
import sys
from typing import List, Dict, Any
from genie4 import AsyncGenieClient, GenieAPIError

async def process_batch_payloads(client: AsyncGenieClient, payloads: List[str]) -> List[Dict[str, Any]]:
    """
    Processes a batch of payloads concurrently with rate-limit throttling
    and structured error recovery.
    """
    semaphore = asyncio.Semaphore(20)  # Max 20 concurrent requests
    
    async def worker(payload: str) -> Dict[str, Any]:
        async with semaphore:
            try:
                response = await client.generate(
                    model="genie-4-standard",
                    prompt=payload,
                    response_format={"type": "json_object"}
                )
                return {"status": "success", "data": response.json()}
            except GenieAPIError as e:
                # Structured error trapping for pipeline consumers
                return {
                    "status": "error", 
                    "error_code": e.status_code, 
                    "message": f"Fix: Verify payload length or adjust token limits. Details: {e.message}"
                }

    tasks = [worker(p) for p in payloads]
    results = await asyncio.gather(*tasks, return_exceptions=False)
    return results

if __name__ == "__main__":
    # Example runner keeping startup fast and pipe-friendly
    client = AsyncGenieClient()
    sample_data = ["Analyze Q1 metrics", "Review security posture", "Summarize logs"]
    
    try:
        loop = asyncio.get_event_loop()
        output = loop.run_until_complete(process_batch_payloads(client, sample_data))
        print(output)
    except Exception as exc:
        print(f"CRITICAL: Batch execution failed. Next step: Run 'genie4 diagnose' for details.", file=sys.stderr)
        sys.exit(1)