"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Norway Makes Shithouses Great Again - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Module: nmssga.persistence
Description: Handles zero-loss local telemetry storage using SQLite WAL mode.
"""

import sqlite3
import json
import logging
from datetime import datetime
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("NMSSGA-Persistence")

DB_PATH = Path("/var/lib/nmssga/facility_telemetry.db")

def init_db() -> None:
    """Initialize the local SQLite database with optimal embedded concurrency settings."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Enable WAL mode for high reliability during sudden power cuts
    cursor.execute("PRAGMA journal_mode=WAL;")
    cursor.execute("PRAGMA synchronous=NORMAL;")
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS telemetry (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            sensor_id TEXT NOT NULL,
            metric_type TEXT NOT NULL,
            value REAL NOT NULL,
            synced INTEGER DEFAULT 0
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            event_category TEXT NOT NULL,
            payload TEXT NOT NULL,
            synced INTEGER DEFAULT 0
        )
    """)
    
    conn.commit()
    conn.close()
    logger.info("Database initialized successfully at %s", DB_PATH)

def log_sensor_reading(sensor_id: str, metric_type: str, value: float) -> None:
    """Record a metric locally with absolute durability guarantees."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    timestamp = datetime.utcnow().isoformat()
    
    try:
        cursor.execute(
            "INSERT INTO telemetry (timestamp, sensor_id, metric_type, value, synced) VALUES (?, ?, ?, ?, 0)",
            (timestamp, sensor_id, metric_type, value)
        )
        conn.commit()
    except sqlite3.Error as e:
        logger.error("Failed to write telemetry to local store: %s", e)
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    init_db()
    log_sensor_reading("temp_internal_01", "celsius", -4.2)
    logger.info("Test telemetry point committed.")

# ============================================================
# Module Implementation Snippet
# ============================================================

#!/usr/bin/env python3
"""
Module: nmssga.thermal_guard
Description: Reads thermistors and modulates heating elements to prevent pipe bursts 
             and LCD screen frost-lock in sub-zero Norwegian environments.
"""

import time
import logging
try:
    import lgpio
    HARDWARE_AVAILABLE = True
except ImportError:
    HARDWARE_AVAILABLE = False

logger = logging.getLogger("NMSSGA-ThermalGuard")

# Configuration Constants
HEATER_GPIO_PIN = 18  # Connected via solid-state relay (SSR)
CRITICAL_FREEZE_THRESHOLD_C = 2.0  # Turn on heating when pipes reach 2°C
TARGET_OPERATING_TEMP_C = 7.0      # Target safety margin

class ThermalController:
    def __init__(self, chip_handle: int = 0):
        self.chip_handle = chip_handle
        self.is_heating = False
        
        if HARDWARE_AVAILABLE:
            self.h = lgpio.gpiochip_open(chip_handle)
            lgpio.gpio_claim_output(self.h, HEATER_GPIO_PIN, 0)
            logger.info("Initialized hardware GPIO pin %d for thermal control.", HEATER_GPIO_PIN)
        else:
            logger.warning("Running in MOCK hardware mode. GPIO commands will be logged only.")

    def read_thermistor_temperature(self) -> float:
        """
        Mock implementation of ADC read from 10k NTC Thermistor.
        In production, replace with SPI/I2C ADC reading (e.g., ADS1115).
        """
        # Simulated sub-zero reading
        return -1.5 

    def evaluate_and_regulate(self) -> None:
        current_temp = self.read_thermistor_temperature()
        logger.info("Current monitored pipe temperature: %.2f°C", current_temp)

        if current_temp <= CRITICAL_FREEZE_THRESHOLD_C and not self.is_heating:
            logger.warning("WARNING: Temperature approaching freezing point! Activating trace heating.")
            self._set_heater_state(True)
        elif current_temp >= TARGET_OPERATING_TEMP_C and self.is_heating:
            logger.info("Temperature stabilized above target. Deactivating trace heating to save power.")
            self._set_heater_state(False)

    def _set_heater_state(self, state: bool) -> None:
        self.is_heating = state
        if HARDWARE_AVAILABLE:
            lgpio.gpio_write(self.h, HEATER_GPIO_PIN, 1 if state else 0)
        else:
            logger.info("[MOCK] Heater relay state changed to: %s", "ON" if state else "OFF")

    def shutdown(self):
        if HARDWARE_AVAILABLE:
            lgpio.gpio_write(self.h, HEATER_GPIO_PIN, 0)
            lgpio.gpiochip_close(self.h)
            logger.info("Thermal controller safely shut down. Heater disabled.")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    controller = ThermalController()
    try:
        for _ in range(3):
            controller.evaluate_and_regulate()
            time.sleep(2)
    finally:
        controller.shutdown()

# ============================================================
# Module Implementation Snippet
# ============================================================

#!/usr/bin/env python3
"""
Module: nmssga.sync_daemon
Description: Periodically wakes the cellular modem, batches unsynced SQLite records,
             pushes to cloud broker via MQTT with TLS, and marks rows as synced.
"""

import sqlite3
import json
import time
import logging
import paho.mqtt.client as mqtt
from pathlib import Path

logger = logging.getLogger("NMSSGA-SyncDaemon")

DB_PATH = Path("/var/lib/nmssga/facility_telemetry.db")
MQTT_BROKER = "mqtt.infrastructure.oslo.gov.no"
MQTT_PORT = 8883
CLIENT_ID = "nmssga_node_finse_04"

def get_unsynced_payloads(limit: int = 50) -> tuple[list, list]:
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("SELECT id, timestamp, sensor_id, metric_type, value FROM telemetry WHERE synced = 0 LIMIT ?", (limit,))
    telemetry_rows = cursor.fetchall()
    
    cursor.execute("SELECT id, timestamp, event_category, payload FROM audit_logs WHERE synced = 0 LIMIT ?", (limit,))
    audit_rows = cursor.fetchall()
    
    conn.close()
    return telemetry_rows, audit_rows

def mark_as_synced(telemetry_ids: list, audit_ids: list) -> None:
    if not telemetry_ids and not audit_ids:
        return
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    if telemetry_ids:
        cursor.executemany("UPDATE telemetry SET synced = 1 WHERE id = ?", [(i,) for i in telemetry_ids])
    if audit_ids:
        cursor.executemany("UPDATE audit_logs SET synced = 1 WHERE id = ?", [(i,) for i in audit_ids])
        
    conn.commit()
    conn.close()
    logger.info("Marked %d telemetry and %d audit records as synced.", len(telemetry_ids), len(audit_ids))

def run_sync_cycle() -> None:
    logger.info("Initiating cellular uplink batch sync...")
    telemetry_rows, audit_rows = get_unsynced_payloads()
    
    if not telemetry_rows and not audit_rows:
        logger.info("No local pending records found. Skipping uplink.")
        return

    client = mqtt.Client(client_id=CLIENT_ID)
    # client.tls_set(ca_certs="/etc/nmssga/certs/ca.crt") # Production TLS setup
    
    try:
        client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
        client.loop_start()
        
        # Format and publish telemetry batch
        if telemetry_rows:
            t_ids = [row[0] for row in telemetry_rows]
            payload = [
                {"id": r[0], "timestamp": r[1], "sensor_id": r[2], "metric_type": r[3], "value": r[4]}
                for r in telemetry_rows
            ]
            info = client.publish(f"nmssga/{CLIENT_ID}/telemetry", json.dumps(payload), qos=1)
            info.wait_for_publish(timeout=10)
            
            if info.is_published():
                mark_as_synced(t_ids, [])
                
        client.loop_stop()
        client.disconnect()
        logger.info("Sync cycle completed successfully.")
        
    except Exception as e:
        logger.error("Cellular connection failed (%s). Retaining local WAL buffer.", e)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_sync_cycle()