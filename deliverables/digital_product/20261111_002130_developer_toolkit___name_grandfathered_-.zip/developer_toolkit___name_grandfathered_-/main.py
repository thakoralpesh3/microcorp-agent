"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: .name Grandfathered - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
name-validate: Production validation utility for .name grandfathered domains.
Exit codes: 0 = Valid, 1 = Invalid format, 2 = Registry/Network error, 64 = Usage error.
"""

import sys
import re
import argparse
import json
from urllib.parse import urlparse

# Strict RFC-compliant regex allowing grandfathered multi-label depth
NAME_TLD_REGEX = re.compile(
    r'^(?=.{1,253}$)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[nN][aA][mM][eE]$'
)

def parse_args():
    parser = argparse.ArgumentParser(
        description="Validate and parse standard and grandfathered .name domains."
    )
    parser.add_argument("domain", help="The .name domain string to validate")
    parser.add_argument("--json", action="store_true", help="Output results in machine-parseable JSON")
    parser.add_argument("--allow-apex", action="store_true", help="Allow bare 'name.name' apex queries")
    return parser.parse_args()

def validate_domain(domain: str, allow_apex: bool) -> dict:
    domain = domain.strip().lower()
    
    if not domain.endswith('.name'):
        return {
            "valid": False,
            "error": "DOMAIN_NOT_NAME_TLD",
            "message": f"Domain '{domain}' does not terminate in '.name'.",
            "fix": "Ensure you are passing a valid .name or grandfathered subdomain."
        }
        
    if not NAME_TLD_REGEX.match(domain):
        return {
            "valid": False,
            "error": "INVALID_SYNTAX",
            "message": f"Domain '{domain}' violates standard DNS label constraints.",
            "fix": "Check for consecutive hyphens, illegal characters, or malformed labels."
        }
        
    labels = domain.split('.')
    if len(labels) < 3:
        if not allow_apex and domain == 'name.name':
            return {
                "valid": False,
                "error": "APEX_NOT_ALLOWED",
                "message": "Bare apex 'name.name' requires --allow-apex flag.",
                "fix": "Provide a fully qualified grandfathered sub-label or use --allow-apex."
            }
        elif len(labels) < 2:
            return {
                "valid": False,
                "error": "MALFORMED_DOMAIN",
                "message": f"Domain '{domain}' has insufficient label depth.",
                "fix": "Provide a complete hostname ending in .name"
            }

    return {
        "valid": True,
        "domain": domain,
        "labels": labels,
        "depth": len(labels),
        "is_grandfathered": len(labels) > 3 or (len(labels) == 3 and labels[0] != 'www')
    }

def main():
    args = parse_args()
    result = validate_domain(args.domain, args.allow_apex)
    
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if result["valid"]:
            print(f"SUCCESS: '{result['domain']}' is valid.")
            print(f"  - Depth: {result['depth']} labels")
            print(f"  - Grandfathered/Custom Structure: {result['is_grandfathered']}")
            sys.exit(0)
        else:
            print(f"ERROR [{result['error']}]: {result['message']}", file=sys.stderr)
            print(f"FIX: {result['fix']}", file=sys.stderr)
            sys.exit(1)

if __name__ == '__main__':
    main()

# ============================================================
# Module Implementation Snippet
# ============================================================

import asyncio
import httpx
import logging
from typing import Optional, Dict, Any

logger = logging.getLogger("name_rdap")
logging.basicConfig(level=logging.INFO)

RDAP_BASE_URL = "https://rdap.verisign.com/name/v1/domain/"

class RDAPLookupError(Exception):
    """Raised when RDAP resolution fails permanently."""
    pass

async def fetch_rdap_record(domain: str, retries: int = 3) -> Dict[str, Any]:
    """
    Queries the Verisign RDAP endpoint for a .name domain with exponential backoff.
    """
    url = f"{RDAP_BASE_URL}{domain}"
    backoff = 0.5

    async with httpx.AsyncClient(timeout=5.0) as client:
        for attempt in range(1, retries + 1):
            try:
                response = await client.get(url, headers={"Accept": "application/json"})
                
                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 404:
                    raise RDAPLookupError(
                        f"Domain '{domain}' not found in registry. "
                        f"Fix: Verify domain spelling or check if registration has expired."
                    )
                elif response.status_code == 429:
                    logger.warning(f"Rate limited on attempt {attempt}/{retries}. Backing off {backoff}s...")
                    await asyncio.sleep(backoff)
                    backoff *= 2
                    continue
                else:
                    response.raise_for_status()
                    
            except httpx.RequestError as e:
                if attempt == retries:
                    raise RDAPLookupError(
                        f"Network failure connecting to RDAP endpoint: {str(e)}. "
                        f"Fix: Check outbound HTTPS connectivity and DNS resolution."
                    )
                await asyncio.sleep(backoff)
                backoff *= 2

        raise RDAPLookupError(
            f"Exhausted {retries} retries querying RDAP for {domain}. "
            f"Fix: Upstream registry may be degraded; implement caching fallback."
        )

# Example Usage Runner
if __name__ == "__main__":
    test_domain = "example.family.name"
    try:
        record = asyncio.run(fetch_rdap_record(test_domain))
        print(f"Successfully retrieved RDAP handle for: {record.get('handle', 'Unknown')}")
    except RDAPLookupError as err:
        print(err, file=sys.stderr)
        sys.exit(2)