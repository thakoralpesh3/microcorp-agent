### Direct UPI Payment Instructions
- **Payee UPI ID:** `talpesh100@ybl`
- **Payee Name:** Alpesh Thakor
- **Amount Due:** ₹399.00 INR (~$4.99 USD)
- **Reference / Order ID:** `ORDER_CD4559E9`
- **Transaction Note:** `MicroCorp: Men's Mental Health Support & `

**Supported Apps:** PhonePe, Google Pay, Paytm, BHIM, Amazon Pay, Cred, or any Indian banking app.
