"""
MicroCorp AI - Turnkey Deliverable
Asset: HackerTube: Developer Toolkit & Architecture Blueprint - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
HackerTube Transcoding Worker Engine
Converts raw input video into multi-bitrate HLS streams.
"""

import subprocess
import sys
import os
from pathlib import Path

def transcode_video(input_path: str, output_dir: str) -> None:
    input_file = Path(input_path)
    if not input_file.exists():
        print(f"Error: Input file not found at {input_file}", file=sys.stderr)
        print("Fix: Verify the file path or run `hacker-tube ingest` to upload a valid file.", file=sys.stderr)
        sys.exit(2)

    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    master_playlist = out_path / "master.m3u8"

    # Production FFmpeg command for 720p / 1080p adaptive HLS output
    cmd = [
        "ffmpeg", "-y", "-i", str(input_file),
        "-filter_complex",
        "[0:v]split=2[v1][v2];"
        "[v1]scale=w=1280:h=720[v720];"
        "[v2]scale=w=1920:h=1080[v1080]",
        "-map", "[v720]", "-c:v:0", "libx264", "-b:v:0", "2800k", "-maxrate:0", "2996k", "-bufsize:0", "4200k",
        "-map", "[v1080]", "-c:v:1", "libx264", "-b:v:1", "5000k", "-maxrate:1", "5350k", "-bufsize:1", "7500k",
        "-map", "0:a", "-c:a", "aac", "-b:a", "128k",
        "-var_stream_map", "v:0,name=720p v:1,name=1080p a:0,name=audio",
        "-master_pl_name", "master.m3u8",
        "-f", "hls",
        "-hls_time", "6",
        "-hls_list_size", "0",
        "-hls_segment_filename", str(out_path / "v%v_%03d.ts"),
        str(out_path / "stream_%v.m3u8")
    ]

    try:
        result = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        print(f"Success: Transcoding completed. Master playlist generated at {master_playlist}")
    except subprocess.CalledProcessError as e:
        print(f"Error: FFmpeg execution failed with exit code {e.returncode}", file=sys.stderr)
        print(f"Details:\n{e.stderr[-1000:]}", file=sys.stderr)
        print("Fix: Ensure FFmpeg 5.x+ is installed and input video has valid audio/video streams.", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python worker.py <input_file> <output_directory>", file=sys.stderr)
        sys.exit(1)
    transcode_video(sys.argv[1], sys.argv[2])