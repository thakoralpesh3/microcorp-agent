@echo off
title MicroCorp AI - Developer Toolkit: macOS Git e
color 0A
echo ========================================================================
echo   MICROCORP AI - 1-CLICK CUSTOMER LAUNCHER
echo   Product: Developer Toolkit: macOS Git eMudhra Certificate Remediation Guide - Developer Reference & Architecture Kit
echo   Commercial Rights: 100%% Transferred to Client
echo ========================================================================
echo.
echo [1/2] Opening interactive customer dashboard in default browser...
start "" "START_HERE.html"
echo.
echo [2/2] Checking Python environment...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Python is not detected in your PATH.
    echo Browse START_HERE.html in your web browser for complete visual docs and code!
) else (
    echo Running standalone source code (main.py)...
    echo.
    python main.py
)
echo.
echo ========================================================================
echo Launcher finished. Press any key to exit.
echo ========================================================================
pause
