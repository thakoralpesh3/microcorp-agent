"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Genie 4 - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

# filename: genie4_client.py
import asyncio
import sys
import json
from typing import AsyncGenerator, Dict, Any
import httpx

API_TIMEOUT = 10.0
MAX_RETRIES = 3

class Genie4ClientError(Exception):
    """Raised when Genie 4 invocation fails permanently."""
    pass

async def invoke_genie4_pipeline(
    endpoint: str, 
    api_key: str, 
    payload: Dict[str, Any]
) -> AsyncGenerator[Dict[str, Any], None]:
    """
    Executes a streaming request against Genie 4 with exponential backoff.
    
    Errors out cleanly with actionable diagnostics if configuration is invalid.
    """
    if not api_key:
        print("Error: GENIE4_API_KEY environment variable is missing.", file=sys.stderr)
        print("Fix: Set export GENIE4_API_KEY='g4_live_...'", file=sys.stderr)
        sys.exit(2)

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "X-Genie-Version": "4.2"
    }

    transport = httpx.AsyncHTTPTransport(retries=0) # Managed manually
    async with httpx.AsyncClient(transport=transport, timeout=API_TIMEOUT) as client:
        backoff = 0.5
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                async with client.stream("POST", endpoint, json=payload, headers=headers) as response:
                    if response.status_code == 429 or response.status_code >= 500:
                        raise httpx.HTTPStatusError(
                            f"Transient server error: {response.status_code}",
                            request=response.request,
                            response=response
                        )
                    response.raise_for_status()
                    
                    async for line in response.aiter_lines():
                        if line.startswith("data: "):
                            yield json.loads(line[6:])
                    return
            
            except (httpx.HTTPStatusError, httpx.TimeoutException) as exc:
                if attempt == MAX_RETRIES:
                    raise Genie4ClientError(
                        f"Failed after {MAX_RETRIES} attempts. Last error: {str(exc)}\n"
                        f"Action: Verify network routing or check status at https://status.microcorp.ai"
                    ) from exc
                
                await asyncio.sleep(backoff)
                backoff *= 2

if __name__ == "__main__":
    # Example execution guard
    print("Genie 4 Production Client Module Loaded Successfully.", file=sys.stderr)