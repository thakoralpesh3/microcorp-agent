"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Norway makes shithouses great again - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

import sqlite3
import time
import json
import paho.mqtt.client as mqtt
from datetime import datetime
from typing import Dict, Any

DB_PATH = "/var/lib/nor_sth/telemetry.db"
MQTT_BROKER = "mqtt.norway-facilities.internal"
MQTT_TOPIC = "nor/sthouse/telemetry/v1"

def init_db():
    """Initialize local SQLite store-and-forward buffer."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS offline_buffer (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            payload TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def store_locally(payload: Dict[str, Any]):
    """Store telemetry payload locally when network is unreachable."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO offline_buffer (payload) VALUES (?)", (json.dumps(payload),))
    conn.commit()
    conn.close()

def flush_buffer(client: mqtt.Client):
    """Flush offline buffer to MQTT broker upon reconnection."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, payload FROM offline_buffer ORDER BY created_at ASC LIMIT 50")
    rows = cursor.fetchall()
    
    if not rows:
        conn.close()
        return

    for row_id, payload_str in rows:
        try:
            result = client.publish(MQTT_TOPIC, payload_str, qos=1)
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                cursor.execute("DELETE FROM offline_buffer WHERE id = ?", (row_id,))
                conn.commit()
        except Exception as e:
            print(f"[-] Failed to flush buffer row {row_id}: {e}")
            break
    conn.close()

def read_sensors() -> Dict[str, Any]:
    """Mock hardware read for frost-resistant load cells and air quality sensors."""
    return {
        "device_id": "lofoten-facility-04",
        "timestamp": datetime.utcnow().isoformat(),
        "temperature_c": -12.4,
        "floor_heating_active": True,
        "occupancy_status": "vacant",
        "consumables": {
            "toilet_paper_pct": 84,
            "hand_soap_pct": 62,
            "water_tank_pct": 90
        },
        "power_draw_watts": 1450.2
    }

if __name__ == "__main__":
    init_db()
    client = mqtt.Client(client_id="LofotenEdgeNode04")
    
    connected = False
    try:
        client.connect(MQTT_BROKER, 1883, 60)
        client.loop_start()
        connected = True
    except Exception:
        print("[-] Initial connection failed. Operating in standalone offline mode.")

    while True:
        data = read_sensors()
        if connected:
            try:
                flush_buffer(client)
                info = client.publish(MQTT_TOPIC, json.dumps(data), qos=1)
                if info.rc != mqtt.MQTT_ERR_SUCCESS:
                    raise IOError("MQTT publish failed")
                print(f"[+] Telemetry sent: {data['device_id']}")
            except Exception:
                print("[-] Network drop detected. Buffering locally.")
                store_locally(data)
                connected = False
        else:
            store_locally(data)
            try:
                client.reconnect()
                connected = True
                print("[+] Reconnected to broker.")
            except Exception:
                pass
        
        time.sleep(60) # Poll every 60 seconds to conserve battery/power