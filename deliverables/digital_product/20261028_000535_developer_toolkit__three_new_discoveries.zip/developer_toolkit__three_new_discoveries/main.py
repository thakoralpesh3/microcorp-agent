"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Three New Discoveries in Mathematics, Computer Science, and Physics - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

"""
Tropical Vector Indexing Engine
Implements Tropical Semiring (min, +) distance metrics for exact nearest-neighbor retrieval.
"""

import numpy as np
from typing import Tuple, List

class TropicalVectorIndex:
    def __init__(self, dimensions: int):
        self.dim = dimensions
        self.vectors: List[np.ndarray] = []
        self.ids: List[str] = []

    def _tropical_distance(self, u: np.ndarray, v: np.ndarray) -> float:
        """
        Computes the tropical (min, +) metric (Maximal Tropical Distance).
        d_trop(u, v) = max_i |u_i - v_i| evaluated via tropical convolution.
        """
        # Replace expensive floating point products with tropical difference bounds
        return float(np.max(np.abs(u - v)))

    def insert(self, vector_id: str, vector: np.ndarray) -> None:
        if vector.shape[0] != self.dim:
            raise ValueError(
                f"Dimension mismatch: expected {self.dim}, got {vector.shape[0]}. "
                f"Fix: Initialize index with TropicalVectorIndex(dimensions={vector.shape[0]})"
            )
        self.vectors.append(vector.astype(np.float32))
        self.ids.append(vector_id)

    def query(self, target: np.ndarray, k: int = 1) -> List[Tuple[str, float]]:
        if not self.vectors:
            return []
        
        # Vectorized tropical distance computation
        stack = np.vstack(self.vectors)
        distances = np.max(np.abs(stack - target), axis=1)
        
        # Partition to find top-k smallest tropical distances
        k = min(k, len(self.vectors))
        idx = np.argpartition(distances, k)[:k]
        sorted_indices = idx[np.argsort(distances[idx])]
        
        return [(self.ids[i], float(distances[i])) for i in sorted_indices]

# --- Example Usage ---
if __name__ == "__main__":
    index = TropicalVectorIndex(dimensions=128)
    index.insert("doc_alpha", np.random.randn(128))
    index.insert("doc_beta", np.random.randn(128))
    
    results = index.query(np.random.randn(128), k=1)
    print("Tropical Query Results:", results)