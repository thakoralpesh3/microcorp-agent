"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: HackerTube: YouTube built from Hacker News video recommendations - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

import asyncio
import re
import httpx
from typing import List, Dict, Set
from urllib.parse import urlparse, parse_qs

HN_TOP_STORIES = "https://hacker-news.firebaseio.com/v0/topstories.json"
HN_ITEM_URL = "https://hacker-news.firebaseio.com/v0/item/{}.json"
YT_REGEX = re.compile(r'(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})')

async def fetch_json(client: httpx.AsyncClient, url: str) -> dict:
    response = await client.get(url, timeout=10.0)
    return response.json()

def extract_youtube_id(text: str) -> Set[str]:
    if not text:
        return set()
    return set(YT_REGEX.findall(text))

async def process_comment(client: httpx.AsyncClient, comment_id: int, found_videos: Dict[str, int]):
    item = await fetch_json(client, HN_ITEM_URL.format(comment_id))
    if not item or item.get("deleted") or item.get("dead"):
        return
    
    text = item.get("text", "")
    video_ids = extract_youtube_id(text)
    for vid in video_ids:
        found_videos[vid] = found_videos.get(vid, 0) + 1
        
    # Recursively check kids if available
    kids = item.get("kids", [])
    if kids:
        await asyncio.gather(*(process_comment(client, kid, found_videos) for kid in kids[:10]))

async def scan_hacker_news_videos() -> Dict[str, int]:
    async with httpx.AsyncClient() as client:
        top_ids = await fetch_json(client, HN_TOP_STORIES)
        found_videos: Dict[str, int] = {}
        
        # Scan top 30 stories concurrently
        stories = await asyncio.gather(*(fetch_json(client, HN_ITEM_URL.format(sid)) for sid in top_ids[:30]))
        
        tasks = []
        for story in stories:
            if not story:
                continue
            # Check story text/url
            if story.get("url"):
                for vid in extract_youtube_id(story["url"]):
                    found_videos[vid] = found_videos.get(vid, 0) + 5 # Weight direct submissions higher
            
            for kid in story.get("kids", [])[:15]:
                tasks.append(process_comment(client, kid, found_videos))
                
        await asyncio.gather(*tasks)
        return found_videos

if __name__ == "__main__":
    results = asyncio.run(scan_hacker_news_videos())
    print(f"Discovered {len(results)} unique videos from Hacker News.")
    for vid, score in sorted(results.items(), key=lambda x: x[1], reverse=True)[:5]:
        print(f"https://youtube.com/watch?v={vid} (Score: {score})")