"""
MicroCorp AI - Turnkey Deliverable
Asset: USPS Official ZIP Code Boundary Polygons Developer Toolkit - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

"""
Module: usps_spatial_engine.py
Description: Enterprise-grade Point-in-Polygon lookup engine with R-tree indexing.
Dependencies: geopandas, shapely, pydantic
"""

from typing import Dict, Optional, Tuple
import geopandas as gpd
from pydantic import BaseModel, Field
from shapely.geometry import Point
from shapely.strtree import STRtree


class GeoCoordinate(BaseModel):
    latitude: float = Field(..., ge=-90.0, le=90.0, description="WGS84 Latitude")
    longitude: float = Field(..., ge=-180.0, le=180.0, description="WGS84 Longitude")


class USPSSpatialEngine:
    def __init__(self, geojson_path: str):
        print(f"[INFO] Loading boundary polygons from {geojson_path}...")
        self.gdf = gpd.read_file(geojson_path)
        
        # Ensure standard WGS84 Coordinate Reference System
        if self.gdf.crs != "EPSG:4326":
            self.gdf = self.gdf.to_crs("EPSG:4326")
            
        # Build R-tree spatial index using Shapely STRtree for sub-ms queries
        self.tree = STRtree(self.gdf.geometry.values)
        print(f"[SUCCESS] Indexed {len(self.gdf)} ZIP Code polygons successfully.")

    def lookup_zip(self, coord: GeoCoordinate) -> Optional[Dict[str, str]]:
        """
        Performs spatial lookup returning the matching ZIP code metadata.
        Fails fast with structured error context if out of bounds.
        """
        point = Point(coord.longitude, coord.latitude)
        
        # Query R-tree for potential candidate polygon indices
        possible_matches_index = self.tree.query(point)
        
        if len(possible_matches_index) == 0:
            return None

        # Precise secondary check against actual polygon boundaries
        for idx in possible_matches_index:
            polygon = self.gdf.geometry.iloc[idx]
            if polygon.contains(point):
                record = self.gdf.iloc[idx]
                return {
                    "zip_code": str(record.get("ZCTA5CE10", record.get("ZIP", "UNKNOWN"))),
                    "state": str(record.get("STATEFP10", "US")),
                    "land_area_sq_meters": float(record.get("ALAND10", 0.0))
                }
                
        return None


# --- Example Execution ---
if __name__ == "__main__":
    import sys
    
    try:
        engine = USPSSpatialEngine("./data/usps_zips_optimized.geojson")
        test_coord = GeoCoordinate(latitude=37.7749, longitude=-122.4194)
        
        result = engine.lookup_zip(test_coord)
        if result:
            print(f"Found ZIP: {result}")
        else:
            print("Coordinate outside recognized USPS boundary polygons.")
            
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)