"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Show HN: Subvocal – Talk to your computer without making noise - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Subvocal Enterprise Daemon Client
Consumes real-time intent streams from the local Subvocal socket.
"""

import asyncio
import json
import sys
from pathlib import Path

SOCKET_PATH = Path("/var/run/subvocal/daemon.sock")

async def handle_intent_stream() -> None:
    if not SOCKET_PATH.exists():
        print(
            f"Error: Subvocal daemon socket not found at {SOCKET_PATH}.\n"
            "Fix: Run `subvocal daemon start` to initialize the background service.",
            file=sys.stderr
        )
        sys.exit(66) # EX_NOINPUT

    while True:
        try:
            reader, _ = await asyncio.open_unix_connection(str(SOCKET_PATH))
            while True:
                line = await reader.readline()
                if not line:
                    break
                
                event = json.loads(line.decode("utf-8").strip())
                if event.get("confidence", 0.0) >= 0.85:
                    print(f"[INTENT] Executing: {event['intent']} (Score: {event['confidence']})")
                    # Trigger downstream enterprise automation here
                    
        except ConnectionRefusedError:
            print("Warning: Connection lost. Retrying in 1 second...", file=sys.stderr)
            await asyncio.sleep(1.0)
        except Exception as e:
            print(f"Error: Unexpected stream failure: {e}\nFix: Check `subvocal logs` for diagnostics.", file=sys.stderr)
            sys.exit(70) # EX_SOFTWARE

if __name__ == "__main__":
    try:
        asyncio.run(handle_intent_stream())
    except KeyboardInterrupt:
        print("\nShutting down Subvocal client gracefully.")
        sys.exit(0)