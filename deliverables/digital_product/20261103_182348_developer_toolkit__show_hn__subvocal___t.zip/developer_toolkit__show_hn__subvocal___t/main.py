"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Show HN: Subvocal – Talk to your computer without making noise - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
subvocal_dispatcher.py
Consumes Subvocal JSON event streams and dispatches hotkeys or API requests.
"""

import sys
import json
import socket
import subprocess
from typing import Dict, Any

SOCKET_PATH = "/var/run/subvocal.sock"

def execute_action(intent: str) -> None:
    actions: Dict[str, list] = {
        "IDE_NEXT_TAB": ["xdotool", "key", "ctrl+Tab"],
        "TERMINAL_TOGGLE": ["i3-msg", "[class=Alacritty] scratchpad toggle"],
        "AI_COMPLETE": ["curl", "-s", "http://localhost:11434/api/generate", "-d", '{"model": "codellama", "prompt": "explain selection"}']
    }
    
    if intent in actions:
        try:
            subprocess.run(actions[intent], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"[ACTION] Dispatched: {intent}", flush=True)
        except subprocess.SubprocessError as e:
            print(f"[ERROR] Failed to execute action for {intent}: {e}", file=sys.stderr)
    else:
        print(f"[WARN] Unmapped intent received: {intent}", flush=True)

def main() -> None:
    print(f"Connecting to Subvocal daemon at {SOCKET_PATH}...")
    try:
        client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        client.connect(SOCKET_PATH)
    except FileNotFoundError:
        print(f"Error: Subvocal socket not found at {SOCKET_PATH}.\nFix: Start the background service using `subvocal daemon start`.", file=sys.stderr)
        sys.exit(1)

    file_obj = client.makefile('r', encoding='utf-8')
    try:
        for line in file_obj:
            line = line.strip()
            if not line:
                continue
            try:
                data: Dict[str, Any] = json.loads(line)
                if data.get("confidence", 0.0) >= 0.80:
                    execute_action(data["intent"])
            except json.JSONDecodeError:
                continue
    except KeyboardInterrupt:
        print("\nShutting down Subvocal dispatcher.")
    finally:
        client.close()

if __name__ == "__main__":
    main()