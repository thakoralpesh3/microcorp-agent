"""
MicroCorp AI - Turnkey Deliverable
Asset: USPS Official ZIP Code Boundary Polygons: Developer Implementation Toolkit & Integration Cheatsheet - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

"""
USPS Polygon Cleaner & Validator Pipeline
Requirements: pip install geopandas shapely pyogrio
"""
import sys
import geopandas as gpd
from shapely.validation import make_valid
import pyproj

def process_zip_boundaries(input_path: str, output_path: str) -> None:
    try:
        print(f"[*] Loading dataset from: {input_path}")
        # Use pyogrio engine for blazing-fast I/O
        gdf = gpd.read_file(input_path, engine="pyogrio")
    except Exception as e:
        print(f"[ERROR] Failed to load spatial file: {e}", file=sys.stderr)
        print("[FIX] Verify file path exists and is a valid GeoJSON, Shapefile, or GeoParquet.", file=sys.stderr)
        sys.exit(1)

    # 1. Normalize Coordinate Reference System to WGS84
    if gdf.crs is None:
        print("[WARNING] Missing CRS. Forcing EPSG:4326.", file=sys.stderr)
        gdf.set_crs("EPSG:4326", inplace=True)
    elif gdf.crs != "EPSG:4326":
        print(f"[*] Reprojecting from {gdf.crs} to EPSG:4326")
        gdf = gdf.to_crs("EPSG:4326")

    # 2. Topology Repair Loop
    print("[*] Checking and repairing geometry topologies...")
    invalid_count = (~gdf.is_valid).sum()
    if invalid_count > 0:
        print(f"[*] Found {invalid_count} invalid geometries. Applying `make_valid()`...")
        gdf['geometry'] = gdf['geometry'].apply(lambda geom: make_valid(geom) if not geom.is_valid else geom)

    # 3. Ensure MultiPolygon consistency
    gdf['geometry'] = gdf['geometry'].apply(
        lambda geom: geom if geom.geom_type in ['Polygon', 'MultiPolygon'] else None
    )
    gdf = gdf.dropna(subset=['geometry'])

    # 4. Standardize ZIP code column schema
    if 'ZIP' in gdf.columns:
        gdf = gdf.rename(columns={'ZIP': 'zip_code'})
    
    gdf['zip_code'] = gdf['zip_code'].astype(str).str.zfill(5)

    # 5. Export to optimized GeoParquet format
    try:
        print(f"[*] Exporting cleaned dataset to: {output_path}")
        gdf.to_parquet(output_path, compression='snappy')
        print("[SUCCESS] Pipeline completed successfully.")
    except Exception as e:
        print(f"[ERROR] Export failed: {e}", file=sys.stderr)
        sys.exit(2)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python clean_zips.py <input_file> <output_parquet>", file=sys.stderr)
        sys.exit(1)
    process_zip_boundaries(sys.argv[1], sys.argv[2])