"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: GPT-5.6 Sol can beat Factorio on peaceful mode - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Sol Hierarchical Planner - Core reasoning loop for GPT-5.6 Sol.
Ensures deterministic JSON schema output for Factorio RCON commands.
"""

import sys
import json
from typing import Dict, Any
from pydantic import BaseModel, Field, ValidationError

class FactorioAction(BaseModel):
    action_type: str = Field(..., description="e.g., BUILD,CRAFT,RESEARCH,LOGISTICS")
    target_entity: str = Field(..., description="Exact entity name in Factorio data raw")
    coordinates: Dict[str, int] = Field(..., description="{'x': int, 'y': int}")
    parameters: Dict[str, Any] = Field(default_factory=dict)

class SolExecutionPlan(BaseModel):
    current_objective: str
    reasoning: str
    actions: list[FactorioAction]

def parse_sol_response(raw_llm_output: str) -> SolExecutionPlan:
    """
    Parses LLM output against the strict execution schema.
    Fails with an actionable remediation message if validation fails.
    """
    try:
        data = json.loads(raw_llm_output)
        return SolExecutionPlan(**data)
    except json.JSONDecodeError as jde:
        print(f"Error: Malformed JSON from model — line {jde.lineno}, column {jde.colno}.", file=sys.stderr)
        print("Fix: Ensure model temperature is set <= 0.2 and system prompt enforces strict JSON mode.", file=sys.stderr)
        sys.exit(2)
    except ValidationError as ve:
        print(f"Error: Sol execution plan violates structural contract.", file=sys.stderr)
        print(f"Details: {ve.errors()}", file=sys.stderr)
        print("Fix: Review prompt engineering schema constraints in './prompts/sol-base.toml'.", file=sys.stderr)
        sys.exit(3)

if __name__ == "__main__":
    # Mocking a validated Sol response stream
    mock_sol_payload = """
    {
        "current_objective": "Bootstrap initial iron plate production line",
        "reasoning": "Burner mining drills require coal fuel feed loop connected to stone furnaces.",
        "actions": [
            {
                "action_type": "BUILD",
                "target_entity": "burner-mining-drill",
                "coordinates": {"x": 12, "y": -4},
                "parameters": {"facing": "NORTH", "fuel_target": "coal"}
            },
            {
                "action_type": "BUILD",
                "target_entity": "stone-furnace",
                "coordinates": {"x": 12, "y": -2},
                "parameters": {"output": "iron-plate"}
            }
        ]
    }
    """
    plan = parse_sol_response(mock_sol_payload)
    print(f"[Sol-Engine] Objective Loaded: {plan.current_objective}")
    print(f"[Sol-Engine] Executing {len(plan.actions)} atomic actions via RCON...")
    sys.exit(0)