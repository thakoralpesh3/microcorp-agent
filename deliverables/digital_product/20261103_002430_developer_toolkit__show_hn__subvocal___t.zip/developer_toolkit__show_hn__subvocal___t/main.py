"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Show HN: Subvocal – Talk to Your Computer Without Making Noise - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Subvocal Audio Ingestion Ring Buffer
- Zero allocation on the hot path
- Thread-safe producer-consumer model for audio streams
"""

import sys
import numpy as np
from typing import Generator

class AudioRingBuffer:
    def __init__(self, capacity_frames: int, channels: int = 1):
        self.capacity = capacity_frames
        self.channels = channels
        self.buffer = np.zeros((capacity_frames, channels), dtype=np.float32)
        self.head = 0
        self.size = 0

    def write(self, chunk: np.ndarray) -> None:
        chunk_len = len(chunk)
        if chunk_len > self.capacity:
            raise ValueError(
                f"Error: Chunk size ({chunk_len}) exceeds buffer capacity ({self.capacity}). "
                "Fix: Increase buffer capacity or decrease chunk size in subvocal.toml."
            )
        
        space_left = self.capacity - self.head
        if chunk_len <= space_left:
            self.buffer[self.head:self.head + chunk_len] = chunk
        else:
            self.buffer[self.head:] = chunk[:space_left]
            self.buffer[:chunk_len - space_left] = chunk[space_left:]
            
        self.head = (self.head + chunk_len) % self.capacity
        self.size = min(self.capacity, self.size + chunk_len)

    def read_latest(self, num_frames: int) -> np.ndarray:
        if num_frames > self.size:
            print(f"Warning: Requested {num_frames} frames, but only {self.size} available.", file=sys.stderr)
            num_frames = self.size
            
        start_idx = (self.head - num_frames) % self.capacity
        if start_idx < self.head:
            return self.buffer[start_idx:self.head].copy()
        else:
            return np.vstack((self.buffer[start_idx:], self.buffer[:self.head]))

if __name__ == "__main__":
    # Test harness
    try:
        ring = AudioRingBuffer(capacity_frames=16000)
        dummy_chunk = np.random.randn(160, 1).astype(np.float32)
        ring.write(dummy_chunk)
        latest = ring.read_latest(160)
        print(f'{{"status": "success", "frames_read": {len(latest)}}}')
        sys.exit(0)
    except Exception as e:
        print(f'{{"error": "{str(e)}", "fix": "Check buffer bounds and data types."}}', file=sys.stderr)
        sys.exit(1)

# ============================================================
# Module Implementation Snippet
# ============================================================

#!/usr/bin/env python3
"""
Subvocal ONNX Inference Engine
- Loads quantized tiny-whisper/subvocal encoder
- Enforces strict input validation and explicit error codes
"""

import sys
import os
from pathlib import Path
import numpy as np

try:
    import onnxruntime as ort
except ImportError:
    print(
        'Error: Missing dependency "onnxruntime".\n'
        'Fix: Run "pip install onnxruntime" or check your virtual environment.',
        file=sys.stderr
    )
    sys.exit(2)

class SubvocalInferenceEngine:
    def __init__(self, model_path: str):
        self.model_path = Path(model_path)
        if not self.model_path.exists():
            print(
                f'Error: Model file not found at "{self.model_path}".\n'
                'Fix: Run "subvocal download-models" to fetch required ONNX weights.',
                file=sys.stderr
            )
            sys.exit(3)
            
        try:
            options = ort.SessionOptions()
            options.intra_op_num_threads = 2
            options.inter_op_num_threads = 1
            self.session = ort.InferenceSession(str(self.model_path), options, providers=['CPUExecutionProvider'])
            self.input_name = self.session.get_inputs()[0].name
        except Exception as e:
            print(
                f'Error: Failed to initialize ONNX runtime session.\n'
                f'Details: {e}\n'
                'Fix: Ensure the ONNX file is not corrupted and compatible with your runtime version.',
                file=sys.stderr
            )
            sys.exit(4)

    def infer(self, mel_spectrogram: np.ndarray) -> np.ndarray:
        if mel_spectrogram.dtype != np.float32:
            mel_spectrogram = mel_spectrogram.astype(np.float32)
        
        try:
            outputs = self.session.run(None, {self.input_name: mel_spectrogram})
            return outputs[0]
        except Exception as e:
            print(
                f'Error: Inference execution failed.\n'
                f'Details: {e}\n'
                'Fix: Verify input tensor dimensions match model signature [Batch, Channels, Time, Frequency].',
                file=sys.stderr
            )
            sys.exit(5)

if __name__ == "__main__":
    print('{"status": "engine_ready"}')
    sys.exit(0)