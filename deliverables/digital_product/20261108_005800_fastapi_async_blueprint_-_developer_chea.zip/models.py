"""
Domain models and schemas for FastAPI Async Blueprint - Developer Cheatsheet & Pattern Kit
"""
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class SolutionConfig:
    app_name: str = "FastAPI Async Blueprint - Developer Cheatsheet & Pattern Kit"
    environment: str = "production"
    debug: bool = False
    max_workers: int = 4
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

@dataclass
class ExecutionResult:
    success: bool
    message: str
    data: Dict[str, Any] = field(default_factory=dict)
    execution_time_ms: float = 0.0
