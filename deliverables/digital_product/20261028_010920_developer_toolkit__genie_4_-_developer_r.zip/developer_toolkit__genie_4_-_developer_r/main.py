"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Genie 4 - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

from typing import List, Optional
from pydantic import BaseModel, Field, ValidationError
from genie4.core import AgentNode, ExecutionContext, guard
from genie4.llm import ChatClient
from genie4.errors import ToolExecutionError

# 1. Define strict input/output contracts
class TicketAnalysisInput(BaseModel):
    ticket_id: str = Field(..., description="Unique ticketing system identifier")
    raw_text: str = Field(..., description="Customer support message content")

class TicketAnalysisOutput(BaseModel):
    category: str = Field(..., description="Billing, Technical, or General")
    urgency_score: int = Field(..., ge=1, le=5, description="1 (Low) to 5 (Critical)")
    suggested_tags: List[str] = Field(default_factory=list)
    escalate_to_human: bool = Field(False)

# 2. Initialize client and node
client = ChatClient.from_env()

class TicketClassifierNode(AgentNode):
    name = "ticket_classifier"
    
    @guard(max_retries=2, fallback_value=None)
    async def execute(self, ctx: ExecutionContext, input_data: TicketAnalysisInput) -> TicketAnalysisOutput:
        prompt = f"""
        Analyze the following support ticket and extract structured metadata.
        Ticket ID: {input_data.ticket_id}
        Content: {input_data.raw_text}
        """
        
        try:
            # Force structured output via Genie 4 native schema binding
            response = await client.complete_structured(
                prompt=prompt,
                response_model=TicketAnalysisOutput,
                temperature=0.1 # Low temperature for deterministic classification
            )
            return response
        except ValidationError as e:
            ctx.logger.error(f"Schema validation failed for ticket {input_data.ticket_id}: {e}")
            raise ToolExecutionError(
                message=f"Malformed LLM output: {e}",
                fix="Verify prompt instructions or adjust model temperature."
            )

# ============================================================
# Module Implementation Snippet
# ============================================================

from genie4.graph import AgentGraph, State
from genie4.routing import NeuralRouter
from genie4.telemetry import trace_execution

# Initialize graph topology
graph = AgentGraph(name="enterprise_support_mesh")

# Define nodes (assuming imported from modules)
from nodes import intake_node, billing_node, technical_node, fallback_node

@trace_execution(service_name="support-mesh")
async def build_support_workflow():
    # Add nodes to the execution plane
    graph.add_node("intake", intake_node)
    graph.add_node("billing", billing_node)
    graph.add_node("technical", technical_node)
    graph.add_node("fallback", fallback_node)
    
    # Configure Neural Router for zero-shot intent dispatch
    router = NeuralRouter(
        classes=["billing", "technical"],
        embedding_model="text-embedding-3-small"
    )
    
    # Define conditional routing from intake
    graph.add_conditional_edge(
        source="intake",
        condition=router.evaluate_intent,
        mapping={
            "billing": "billing",
            "technical": "technical",
            "__default__": "fallback"
        }
    )
    
    # Compile execution graph with state checkpoints enabled
    compiled_graph = graph.compile(
        checkpointer="redis://localhost:6379/0",
        checkpoint_ttl=86400
    )
    return compiled_graph

if __name__ == "__main__":
    import asyncio
    workflow = asyncio.run(build_support_workflow())
    print(f"Workflow compiled successfully: {workflow.metadata.graph_id}")

# ============================================================
# Module Implementation Snippet
# ============================================================

# GOOD
agent = AgentRunner(model="gpt-4o", max_steps=5, on_max_steps="halt_with_error")

# ============================================================
# Module Implementation Snippet
# ============================================================

# GOOD
sanitized_content = sanitizer.clean_html(raw_web_page)
prompt = f"Summarize the following external text:\n<external_data>\n{sanitized_content}\n</external_data>"

# ============================================================
# Module Implementation Snippet
# ============================================================

# BAD: ctx.state["user"] = updated_user
# GOOD:
return StateDelta(updates={"user": updated_user})