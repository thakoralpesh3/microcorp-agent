"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Norway makes shithouses great again - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

"""
Module: arak_thermo_governor.py
Author: AI Engineer, The Agency (MicroCorp AI)
Description: Production-ready thermal regulation and discharge governance 
             for extreme-cold municipal sanitation nodes.
"""

import time
import logging
from dataclasses import dataclass
from typing import Optional

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(name)s: %(message)s')
logger = logging.getLogger("ARAK-THERMO")

@dataclass
class SystemState:
    pipe_temperature_c: float
    ambient_temperature_c: float
    discharge_volume_liters: float
    heating_element_active: bool

class PIDHeatingController:
    """
    Proportional-Integral-Derivative controller designed to anticipate 
    permafrost freezing cycles in remote Norwegian installations.
    """
    def __init__(self, target_temp_c: float = 4.5, kp: float = 2.5, ki: float = 0.1, kd: float = 0.8):
        self.target_temp = target_temp_c
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral = 0.0
        self.previous_error = 0.0

    def compute_pwm_duty_cycle(self, current_temp: float, dt: float) -> float:
        error = self.target_temp - current_temp
        self.integral += error * dt
        derivative = (error - self.previous_error) / dt if dt > 0 else 0.0
        
        output = (self.kp * error) + (self.ki * self.integral) + (self.kd * derivative)
        self.previous_error = error
        
        # Clamp output between 0% (0.0) and 100% (1.0) duty cycle
        return max(0.0, min(1.0, output))


class EnviroQuotaGovernor:
    """
    Enforces strict Norwegian discharge regulations (Forurensningsforskriften).
    Implements a token-bucket algorithm for fluid release.
    """
    def __init__(self, max_capacity_liters: float = 5000.0, refill_rate_per_sec: float = 0.5):
        self.max_capacity = max_capacity_liters
        self.tokens = max_capacity_liters
        self.refill_rate = refill_rate_per_sec
        self.last_update = time.time()

    def _refresh_tokens(self) -> None:
        now = time.time()
        delta = now - self.last_update
        self.tokens = min(self.max_capacity, self.tokens + (delta * self.refill_rate))
        self.last_update = now

    def request_discharge(self, volume_liters: float) -> bool:
        self._refresh_tokens()
        if self.tokens >= volume_liters:
            self.tokens -= volume_liters
            logger.info(f"Discharge approved for {volume_liters}L. Remaining quota: {self.tokens:.2f}L")
            return True
        logger.warning(f"Discharge DENIED. Requested: {volume_liters}L, Available Quota: {self.tokens:.2f}L")
        return False


# --- Execution Example ---
if __name__ == "__main__":
    controller = PIDHeatingController()
    governor = EnviroQuotaGovernor(max_capacity_liters=1000.0, refill_rate_per_sec=2.0)
    
    logger.info("Initializing ARAK Sub-System Node #404-Tromsø...")
    
    # Simulate a freezing event loop
    simulated_pipe_temp = -2.1  # Dangerously below freezing
    dt_step = 1.0               # 1 second tick
    
    for cycle in range(3):
        duty_cycle = controller.compute_pwm_duty_cycle(simulated_pipe_temp, dt_step)
        heating_active = duty_cycle > 0.0
        
        logger.info(f"Cycle {cycle+1} | Temp: {simulated_pipe_temp}C | Heating Duty: {duty_cycle*100:.1f}%")
        
        # Test discharge governance
        governor.request_discharge(150.0)
        
        # Simulate environmental heat response
        simulated_pipe_temp += (duty_cycle * 1.5)
        time.sleep(0.1)