"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Show HN: Subvocal – Talk to Your Computer Without Making Noise - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Subvocal Enterprise Client Daemon Connector
- Low overhead Unix socket client
- Graceful degradation and actionable error reporting
"""

import asyncio
import json
import sys
from pathlib import Path

SOCKET_PATH = Path.home() / ".config" / "subvocal" / "daemon.sock"

async def dispatch_intent(intent: dict) -> None:
    action = intent.get("action")
    payload = intent.get("payload", {})
    
    print(f"[subvocal] Executing intent: {action} with payload {payload}")
    # Simulate safe command execution
    await asyncio.sleep(0.01)

async def listen_loop() -> None:
    if not SOCKET_PATH.exists():
        print(
            f"Error: Subvocal daemon socket not found at {SOCKET_PATH}.\n"
            f"Next Step: Run 'subvocal daemon --start' to initialize the background service.",
            file=sys.stderr
        )
        sys.exit(66) # EX_NOINPUT

    while True:
        try:
            reader, writer = await asyncio.open_unix_connection(str(SOCKET_PATH))
            print("[subvocal] Connected to local inference daemon. Listening for silent signals...")
            
            while data := await reader.readline():
                try:
                    event = json.loads(data.decode().strip())
                    asyncio.create_task(dispatch_intent(event))
                except json.JSONDecodeError:
                    print(f"Warning: Received malformed telemetry frame, dropping.", file=sys.stderr)
                    
        except (ConnectionRefusedError, FileNotFoundError):
            print("Error: Lost connection to Subvocal daemon. Retrying in 2 seconds...", file=sys.stderr)
            await asyncio.sleep(2.0)
        except asyncio.CancelledError:
            break

if __name__ == "__main__":
    try:
        asyncio.run(listen_loop())
    except KeyboardInterrupt:
        print("\n[subvocal] Client shut down gracefully.")
        sys.exit(0)