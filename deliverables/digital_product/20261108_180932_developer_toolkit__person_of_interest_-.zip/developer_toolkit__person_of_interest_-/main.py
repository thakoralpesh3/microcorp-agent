"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Person of Interest - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

"""
Developer Toolkit: Person of Interest (POI)
Module: poi_interceptor.py
Description: Production-grade asynchronous telemetry interceptor and state ledger.
"""

import asyncio
import json
import sys
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Dict, List, Optional

# --- TTY & Pipeline Detection ---
IS_TTY = sys.stdout.isatty()


def emit_log(level: str, message: str, meta: Optional[Dict[str, Any]] = None) -> None:
    """Emits structured output respecting pipe vs TTY constraints."""
    payload = {
        "timestamp": time.time_ns(),
        "level": level.upper(),
        "message": message,
        "meta": meta or {},
    }

    if IS_TTY:
        color_map = {"INFO": "\033[32m", "WARN": "\033[33m", "ERROR": "\033[31m"}
        reset = "\033[0m"
        color = color_map.get(level.upper(), "\033[36m")
        print(f"{color}[POI::{level.upper()}] {message}{reset}")
        if meta:
            for k, v in meta.items():
                print(f"  └── {k}: {v}")
    else:
        # Machine-parseable JSON stream for pipelines and log aggregators
        print(json.dumps(payload), flush=True)


@dataclass
class POIContext:
    poi_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    session_tokens: int = 0
    state_history: List[Dict[str, Any]] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)


class POIInterceptor:
    """Intersects agent execution loops to record state mutations and metrics

    without violating sub-100ms latency budgets.
    """

    def __init__(self, poi_id: Optional[str] = None):
        self.context = POIContext(poi_id=poi_id or str(uuid.uuid4()))
        self._lock = asyncio.Lock()

    async def capture_mutation(
        self, action: str, state_delta: Dict[str, Any], token_cost: int = 0
    ) -> None:
        async with self._lock:
            self.context.session_tokens += token_cost
            entry = {
                "action": action,
                "delta": state_delta,
                "tokens": token_cost,
                "timestamp": time.time(),
            }
            self.context.state_history.append(entry)

            emit_log(
                "INFO",
                f"State mutation captured for POI: {self.context.poi_id[:8]}...",
                {"action": action, "cumulative_tokens": self.context.session_tokens},
            )

    async def execute_monitored_step(
        self, agent_callable: Any, *args: Any, **kwargs: Any
    ) -> Any:
        start_time = time.perf_counter()
        action_name = getattr(agent_callable, "__name__", "anonymous_agent_step")

        try:
            # Execute hot-path agent logic
            result = await agent_callable(*args, **kwargs)
            duration_ms = (time.perf_counter() - start_time) * 1000

            await self.capture_mutation(
                action=action_name,
                state_delta={"status": "success", "duration_ms": duration_ms},
                token_cost=kwargs.get("estimated_tokens", 150),
            )
            return result

        except Exception as exc:
            duration_ms = (time.perf_counter() - start_time) * 1000
            emit_log(
                "ERROR",
                f"Agent step failed: {action_name} — {str(exc)}",
                {"fix": "Verify upstream LLM rate limits or schema validation rules."},
            )
            await self.capture_mutation(
                action=action_name,
                state_delta={"status": "error", "error_message": str(exc)},
            )
            raise


# --- Example Usage ---
async def mock_agent_step(prompt: str) -> str:
    await asyncio.sleep(0.02)  # Simulate fast LLM inference
    return f"Processed: {prompt}"


async def main() -> None:
    tracker = POIInterceptor(poi_id="usr_99a87fbc-4122")

    # Safe execution path
    res = await tracker.execute_monitored_step(
        mock_agent_step, "Analyze quarterly financial logs", estimated_tokens=320
    )
    emit_log("INFO", f"Execution Result: {res}")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        emit_log("WARN", "Process interrupted by user. Exiting cleanly.")
        sys.exit(0)