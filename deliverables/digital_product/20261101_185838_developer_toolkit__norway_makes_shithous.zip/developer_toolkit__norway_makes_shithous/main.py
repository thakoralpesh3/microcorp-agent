"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Norway makes shithouses great again - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

"""
NRAK Edge Telemetry Worker (Python 3.11+)
Handles sub-zero sensor payloads with local SQLite fallback caching.
"""

import asyncio
import json
import sqlite3
import logging
from typing import Dict, Any
import paho.mqtt.client as mqtt

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("NRAK-Edge")

DB_PATH = "nrak_edge_cache.db"

def init_local_cache():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS telemetry_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            payload TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

class NordicFacilityNode:
    def __init__(self, broker_host: str, broker_port: int, client_id: str):
        self.broker_host = broker_host
        self.broker_port = broker_port
        self.client = mqtt.Client(client_id=client_id)
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        init_local_cache()

    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            logger.info("Connected to Norwegian Municipal IoT Mesh successfully.")
            self.client.subscribe("norway/facility/+/telemetry")
        else:
            logger.error(f"Connection failed with code {rc}. Activating local freeze protocol.")

    def on_message(self, client, userdata, msg):
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
            self.process_telemetry(payload)
        except json.JSONDecodeError:
            logger.error("Malformed payload received from edge sensor. Discarding.")
        except Exception as e:
            logger.warning(f"Cloud ingest failed. Flushing payload to local SQLite buffer: {e}")
            self.persist_to_local_cache(msg.payload.decode("utf-8"))

    def process_telemetry(self, data: Dict[str, Any]):
        temp = data.get("ambient_temperature_c", 20.0)
        occupancy = data.get("is_occupied", False)
        hydraulic_pressure = data.get("hydraulic_pressure_bar", 4.5)

        if temp < -15.0:
            logger.critical(f"FREEZE WARNING: Ambient temp at {temp}°C! Engaging heat trace lines.")
        
        logger.info(f"Processed Facility {data.get('facility_id')}: Occ={occupancy}, Pres={hydraulic_pressure}bar")

    def persist_to_local_cache(self, payload_str: str):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO telemetry_queue (payload) VALUES (?)", (payload_str,))
        conn.commit()
        conn.close()

    def run(self):
        try:
            self.client.connect(self.broker_host, self.broker_port, 60)
            self.client.loop_start()
        except Exception as e:
            logger.error(f"Network unreachable ({e}). Running entirely on local cache mode.")

if __name__ == "__main__":
    node = NordicFacilityNode(broker_host="localhost", broker_port=1883, client_id="trondheim_unit_01")
    node.run()
    # Keep execution alive for demonstration
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("Shutting down NRAK Edge Node cleanly.")