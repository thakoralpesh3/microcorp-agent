"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: .name Grandfathered - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
MicroCorp AI .name Grandfathered Status Inspector
Verifies domain status, EPP lock state, and grandfathered flag preservation.
"""

import asyncio
import ssl
import xml.etree.ElementTree as ET
from typing import Dict, Any

EPP_SERVER = "epp.nic.name"
EPP_PORT = 700;
CLIENT_ID = "microcorp-epp-client"
CLIENT_PW = "secure-token-xyz"

async def verify_grandfathered_domain(domain_name: str) -> Dict[str, Any]:
    context = ssl.create_default_context()
    # In production, load client certificates for mutual TLS (mTLS)
    
    try:
        reader, writer = await asyncio.open_connection(
            EPP_SERVER, EPP_PORT, ssl=context
        )
    except Exception as e:
        return {"error": f"Connection failed: {e}. Fix: Verify EPP endpoint and firewall whitelist."}

    # Read greeting
    data = await reader.read(4096)
    
    # Construct Login XML
    login_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="no"?>
    <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
      <command>
        <login>
          <clID>{CLIENT_ID}</clID>
          <pw>{CLIENT_PW}</pw>
          <options>
            <version>1.0</version>
            <lang>en</lang>
          </options>
          <svcs>
            <objURI>urn:ietf:params:xml:ns:domain-1.0</objURI>
          </svcs>
        </login>
        <clTRID>MC-LOGIN-001</clTRID>
      </command>
    </epp>"""
    
    # Send Login
    writer.write(len(login_xml).to_bytes(4, 'big') + login_xml.encode('utf-8'))
    await writer.drain()
    _ = await reader.read(4096) # Consume login response

    # Construct Info Query for .name structure
    info_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="no"?>
    <epp xmlns="urn:ietf:params:xml:ns:epp-1.0">
      <command>
        <info>
          <domain:info xmlns:domain="urn:ietf:params:xml:ns:domain-1.0">
            <domain:name host="all">{domain_name}</domain:name>
          </domain:info>
        </info>
        <clTRID>MC-INFO-002</clTRID>
      </command>
    </epp>"""

    writer.write(len(info_xml).to_bytes(4, 'big') + info_xml.encode('utf-8'))
    await writer.drain()
    
    # Read response length header
    length_header = await reader.read(4)
    if not length_header:
        writer.close()
        await writer.wait_closed()
        return {"error": "Registry dropped connection. Fix: Check EPP command rate limits."}
        
    msg_len = int.from_bytes(length_header, 'big')
    response_data = await reader.read(msg_len)
    
    writer.close()
    await writer.wait_closed()

    # Parse XML
    root = ET.fromstring(response_data.decode('utf-8'))
    
    # Namespace handling for EPP
    ns = {'epp': 'urn:ietf:params:xml:ns:epp-1.0', 'domain': 'urn:ietf:params:xml:ns:domain-1.0'}
    
    # Extract status codes
    statuses = [node.attrib.get('s') for node in root.findall('.//domain:status', ns)]
    
    return {
        "domain": domain_name,
        "statuses": statuses,
        "is_grandfathered_candidate": "clientHold" not in statuses,
        "raw_xml_response": response_data.decode('utf-8')
    }

if __name__ == "__main__":
    import sys
    target = sys.argv[1] if len(sys.argv) > 1 else "john.smith.name"
    result = asyncio.run(verify_grandfathered_domain(target))
    print(result)