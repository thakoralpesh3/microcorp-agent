#!/usr/bin/env bash
# ========================================================================
# MICROCORP AI - 1-CLICK CUSTOMER LAUNCHER (macOS & Linux)
# ========================================================================

echo "========================================================================"
echo "  MICROCORP AI - 1-CLICK CUSTOMER LAUNCHER"
echo "  Product: Developer Toolkit: HackerTube Architecture & Boilerplate - Developer Reference & Architecture Kit"
echo "========================================================================"
echo ""
echo "[1/2] Opening interactive customer dashboard in default browser..."
if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "START_HERE.html" >/dev/null 2>&1 &
elif command -v open >/dev/null 2>&1; then
    open "START_HERE.html" >/dev/null 2>&1 &
fi

echo "[2/2] Running standalone source code (main.py)..."
echo ""
if command -v python3 >/dev/null 2>&1; then
    python3 main.py
elif command -v python >/dev/null 2>&1; then
    python main.py
else
    echo "Python is not installed. Please browse START_HERE.html in your web browser."
fi

echo ""
echo "========================================================================"
echo "Done! Check START_HERE.html or README.md for full details."
echo "========================================================================"
