"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Show HN: Subvocal – Talk to your computer without making noise - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Subvocal Real-Time Intent Listener
-----------------------------------
Captures near-field micro-audio, runs local INT8 ONNX inference,
and emits structured JSON intents to stdout or downstream consumers.
"""

import sys
import json
import time
from pathlib import Path
import numpy as np
import sounddevice as sd
import onnxruntime as ort

# Configuration constants
SAMPLE_RATE = 16000
BLOCK_SIZE = 2048
MODEL_PATH = Path("./models/subvocal-base.quant.onnx")

def validate_environment():
    """Ensure runtime dependencies and models exist before booting."""
    if not MODEL_PATH.exists():
        print(
            f"Error: Model weights not found at '{MODEL_PATH}'.\n"
            f"Next step: Run 'subvocal model download --target {MODEL_PATH}' to fetch required weights.",
            file=sys.stderr
        )
        sys.exit(66) # EX_NOINPUT

def initialize_runtime(model_path: Path) -> ort.InferenceSession:
    """Initialize the ONNX runtime with optimized CPU execution providers."""
    try:
        options = ort.SessionOptions()
        options.intra_op_num_threads = 2
        options.inter_op_num_threads = 1
        options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        
        session = ort.InferenceSession(str(model_path), options, providers=['CPUExecutionProvider'])
        return session
    except Exception as e:
        print(
            f"Error: Failed to initialize ONNX runtime.\n"
            f"Reason: {e}\n"
            f"Next step: Verify your ONNX installation or re-run 'subvocal doctor'.",
            file=sys.stderr
        )
        sys.exit(70) # EX_SOFTWARE

def audio_callback(indata, frames, time_info, status):
    """Ring buffer callback for sounddevice stream."""
    if status:
        print(f"Warning: Audio stream status: {status}", file=sys.stderr)
    
    # Push audio chunk into processing queue (simulated here via global/closure)
    audio_queue.append(indata.copy())

audio_queue = []

def main():
    validate_environment()
    session = initialize_runtime(MODEL_PATH)
    
    input_name = session.get_inputs()[0].name
    
    # Determine output mode (TTY vs Pipe)
    is_tty = sys.stdout.isatty()
    
    if is_tty:
        print(f"🎙️ Subvocal engine active. Listening via default input device... (Press Ctrl+C to exit)")

    try:
        with sd.InputStream(samplerate=SAMPLE_RATE, channels=1, blocksize=BLOCK_SIZE, callback=audio_callback):
            while True:
                if len(audio_queue) > 0:
                    chunk = audio_queue.pop(0)
                    
                    # Preprocessing: Normalization and feature extraction
                    tensor = np.expand_dims(chunk.flatten().astype(np.float32), axis=0)
                    
                    # Inference
                    outputs = session.run(None, {input_name: tensor})
                    logits = outputs[0]
                    predicted_token_id = int(np.argmax(logits))
                    
                    # Emit structured output
                    payload = {
                        "timestamp": time.time(),
                        "token_id": predicted_token_id,
                        "confidence": float(np.max(softmax(logits)))
                    }
                    
                    if is_tty:
                        print(f"-> Intent Detected: ID={payload['token_id']} (Conf: {payload['confidence']:.2f})")
                    else:
                        # Machine-readable output when piped
                        print(json.dumps(payload), flush=True)
                
                time.sleep(0.01)
                
    except KeyboardInterrupt:
        if is_tty:
            print("\nShutting down Subvocal engine gracefully.")
        sys.exit(0)

def softmax(x):
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum(axis=0)

if __name__ == "__main__":
    main()