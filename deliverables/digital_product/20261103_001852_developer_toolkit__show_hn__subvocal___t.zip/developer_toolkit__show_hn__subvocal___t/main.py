"""
MicroCorp AI - Turnkey Deliverable
Asset: Developer Toolkit: Show HN: Subvocal – Talk to your computer without making noise - Developer Reference & Architecture Kit
Category: digital_product
Commercial Rights: 100% Client Ownership
Official Beneficiary: Alpesh Thakor (UPI: talpesh100@ybl)
"""

#!/usr/bin/env python3
"""
Subvocal Daemon Engine - High-Performance Inference Runner
"""
import sys
import json
import asyncio
from pathlib import Path
import numpy as np

def emit_error(msg: str, exit_code: int = 1):
    """Prints structured error adhering to CLI guidelines and exits."""
    payload = {"status": "error", "message": msg, "fix": "Run 'subvocal init --help' for troubleshooting guide."}
    sys.stderr.write(json.dumps(payload) + "\n")
    sys.exit(exit_code)

async def load_model(model_path: Path):
    if not model_path.exists():
        emit_error(f"Model file not found at {model_path}. Fix: Run `subvocal download-model --default`.")
    # Simulated ONNX session load
    await asyncio.sleep(0.01) 
    return {"session": "loaded", "path": str(model_path)}

async def main_loop(model_path: Path, threshold: float, dry_run: bool):
    model = await load_model(model_path)
    sys.stdout.write(json.dumps({"status": "ready", "model": model["path"]}) + "\n")
    sys.stdout.flush()

    while True:
        try:
            # Simulate receiving tensor from sensor ring buffer
            await asyncio.sleep(0.05)
            simulated_logits = np.array([0.02, 0.91, 0.05, 0.02]) # Intent 1 exceeds threshold
            confidence = float(np.max(simulated_logits))
            intent_id = int(np.argmax(simulated_logits))

            if confidence >= threshold:
                action = f"exec_macro_{intent_id}"
                if dry_run:
                    print(json.dumps({"event": "intent_matched", "intent": intent_id, "confidence": confidence, "action": action, "mode": "dry-run"}))
                else:
                    # Execute action
                    print(json.dumps({"event": "dispatch", "intent": intent_id, "confidence": confidence}))
                    sys.stdout.flush()
        except KeyboardInterrupt:
            sys.stdout.write(json.dumps({"status": "shutdown", "reason": "user_interrupt"}) + "\n")
            sys.exit(0)

if __name__ == "__main__":
    model_p = Path.expanduser(Path("~/.subvocal/models/default.onnx"))
    try:
        asyncio.run(main_loop(model_p, threshold=0.85, dry_run=True))
    except Exception as e:
        emit_error(f"Unexpected runtime failure: {str(e)}")